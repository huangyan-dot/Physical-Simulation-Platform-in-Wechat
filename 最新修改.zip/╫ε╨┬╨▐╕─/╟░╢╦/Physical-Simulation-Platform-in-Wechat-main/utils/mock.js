// utils/mock.js - 无后端时的演示数据，上线前删除即可

export const MOCK_LEVELS = [];

export const MOCK_PROGRESS = {
  total: 0,
  passed: 0,
  best_score: 0,
  avg_score: 0,
  records: []
};

export const MOCK_CLASSES = [
  { id: 1, name: '物理实验1班', teacher_name: '张老师', member_count: 32 },
  { id: 2, name: '物理实验2班', teacher_name: '李老师', member_count: 28 }
];

export const MOCK_CLASS_STATS = {
  summary: { avg_score: 78.5, pass_rate: 0.72 },
  rows: [
    { user_id: 1, name: '测试同学', student_no: '20240001', best_score: 88, attempts: 3, passed: true },
    { user_id: 2, name: '小明', student_no: '20240002', best_score: 65, attempts: 5, passed: true },
    { user_id: 3, name: '小红', student_no: '20240003', best_score: 42, attempts: 2, passed: false }
  ]
};