package router

import (
	"net/http"

	"github.com/gin-gonic/gin"

	"backend/internal/config"
	"backend/internal/controller"
	"backend/internal/middleware"
)

// Setup 注册全部路由（README"当前接口"表；v0.15 新增用户模块 CRUD）。
// 中间件链：Recovery（全局异常捕获）-> gin.Logger（访问日志）-> CORS（跨域）。
// 鉴权在分组上挂 middleware.Auth，敏感接口再叠 RequireRole 角色守卫；
// 登录与 /ping 除外（契约 §0）。
func Setup(r *gin.Engine, cfg *config.Config, auth *controller.AuthController, users *controller.UserController) {
	r.Use(middleware.Recovery(), gin.Logger(), middleware.CORS(cfg))

	// 健康检查（MySQL 降级模式下唯一可用接口）
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(http.StatusOK, gin.H{"message": "pong"})
	})

	// 登录无需鉴权；allow_dev_backdoor=true 时额外注册 POST /login 别名（README 灰度约定）
	r.POST("/auth/login", auth.Login)
	if cfg.AllowDevBackdoor {
		r.POST("/login", auth.Login)
	}

	// JWT 鉴权分组
	authed := r.Group("", middleware.Auth(cfg.JWT.Secret))
	{
		authed.GET("/auth/me", auth.Me)

		// 用户模块（v0.15 新增，契约 §19-§23）：完整 CRUD
		ug := authed.Group("/users")
		{
			ug.GET("", middleware.RequireRole("teacher", "admin"), users.List)   // §21 列表
			ug.POST("", middleware.RequireRole("admin"), users.Create)           // §19 新增
			ug.GET("/:id", users.Get)                                            // §20 查单个（本人/teacher/admin）
			ug.PUT("/:id", users.Update)                                         // §22 修改（本人学籍/admin 全量）
			ug.DELETE("/:id", middleware.RequireRole("admin"), users.Delete)      // §23 删除
		}

		// 审计日志查询（契约 §13，admin）
		ag := authed.Group("/admin", middleware.RequireRole("admin"))
		{
			ag.GET("/operation-logs", users.OperationLogs)
		}
	}
}
