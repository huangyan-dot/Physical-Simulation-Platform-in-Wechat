package repository

import (
	"context"

	"gorm.io/gorm"

	"backend/internal/model"
)

// LogRepository 操作审计表数据访问（契约 §13 的查询侧；写入侧由 service 调 Create）。
type LogRepository struct {
	db *gorm.DB
}

// NewLogRepository 构造（main 装配）。
func NewLogRepository(db *gorm.DB) *LogRepository { return &LogRepository{db: db} }

// PageLogsQuery 审计分页查询条件（service 校验后传入：page>=1、size 1~200）。
type PageLogsQuery struct {
	Page   int
	Size   int
	UserID *uint  // 可选，按操作者过滤
	Action string // 可选，按动作过滤（如 login/user.create）
}

// Create 写一条审计日志（调用方 best-effort：失败仅 zap 告警，不影响主流程）。
func (r *LogRepository) Create(ctx context.Context, log *model.OperationLog) error {
	return r.db.WithContext(ctx).Create(log).Error
}

// Page 分页查询审计日志，新→旧（id 倒序近似时间倒序，且与 id 升序建索引一致）。
func (r *LogRepository) Page(ctx context.Context, q PageLogsQuery) (int64, []model.OperationLog, error) {
	tx := r.db.WithContext(ctx).Model(&model.OperationLog{})
	if q.UserID != nil {
		tx = tx.Where("user_id = ?", *q.UserID)
	}
	if q.Action != "" {
		tx = tx.Where("action = ?", q.Action)
	}
	var total int64
	if err := tx.Count(&total).Error; err != nil {
		return 0, nil, err
	}
	var logs []model.OperationLog
	if err := tx.Order("id DESC").Offset((q.Page - 1) * q.Size).Limit(q.Size).Find(&logs).Error; err != nil {
		return 0, nil, err
	}
	return total, logs, nil
}
