package repository

import (
	"context"

	"gorm.io/gorm"

	"backend/internal/model"
)

// UserRepository 用户表数据访问（GORM）。只做纯 SQL 语义，不含业务规则；
// not found 统一返回 gorm.ErrRecordNotFound，由 service 层映射 404。
type UserRepository struct {
	db *gorm.DB
}

// NewUserRepository 构造（main 装配）。
func NewUserRepository(db *gorm.DB) *UserRepository { return &UserRepository{db: db} }

// ListUsersQuery 列表查询条件（service 校验后传入：page>=1、size 1~200）。
type ListUsersQuery struct {
	Page    int
	Size    int
	Role    string // 可选，精确过滤
	Keyword string // 可选，name/student_no 模糊匹配
}

// Create 插入用户。openid/student_no 唯一索引冲突返回驱动错误
// （gorm TranslateError 开启时为 gorm.ErrDuplicatedKey），由上层映射 409。
func (r *UserRepository) Create(ctx context.Context, u *model.User) error {
	return r.db.WithContext(ctx).Create(u).Error
}

// FindByID 按主键查询。
func (r *UserRepository) FindByID(ctx context.Context, id uint) (*model.User, error) {
	var u model.User
	if err := r.db.WithContext(ctx).First(&u, id).Error; err != nil {
		return nil, err
	}
	return &u, nil
}

// FindByOpenID 按微信 openid 查询（登录与唯一性预检路径）。
func (r *UserRepository) FindByOpenID(ctx context.Context, openid string) (*model.User, error) {
	var u model.User
	if err := r.db.WithContext(ctx).Where("openid = ?", openid).First(&u).Error; err != nil {
		return nil, err
	}
	return &u, nil
}

// FindByStudentNo 按学号查询（唯一性预检路径）。
func (r *UserRepository) FindByStudentNo(ctx context.Context, no string) (*model.User, error) {
	var u model.User
	if err := r.db.WithContext(ctx).Where("student_no = ?", no).First(&u).Error; err != nil {
		return nil, err
	}
	return &u, nil
}

// Page 分页查询：返回总数与当前页记录，按 id 升序保证翻页稳定。
// keyword 为空、role 为空时不过滤（全部用户）。
func (r *UserRepository) Page(ctx context.Context, q ListUsersQuery) (int64, []model.User, error) {
	tx := r.db.WithContext(ctx).Model(&model.User{})
	if q.Role != "" {
		tx = tx.Where("role = ?", q.Role)
	}
	if q.Keyword != "" {
		like := "%" + q.Keyword + "%"
		tx = tx.Where("name LIKE ? OR student_no LIKE ?", like, like)
	}
	var total int64
	if err := tx.Count(&total).Error; err != nil {
		return 0, nil, err
	}
	var users []model.User
	if err := tx.Order("id").Offset((q.Page - 1) * q.Size).Limit(q.Size).Find(&users).Error; err != nil {
		return 0, nil, err
	}
	return total, users, nil
}

// Save 全量保存更新（GORM 语义：含 NULL 字段，可清空 student_no/class_id 等可空列）。
func (r *UserRepository) Save(ctx context.Context, u *model.User) error {
	return r.db.WithContext(ctx).Save(u).Error
}

// Delete 按主键物理删除（用户表无软删字段，避免软删行占用唯一索引）。
func (r *UserRepository) Delete(ctx context.Context, id uint) error {
	return r.db.WithContext(ctx).Delete(&model.User{}, id).Error
}
