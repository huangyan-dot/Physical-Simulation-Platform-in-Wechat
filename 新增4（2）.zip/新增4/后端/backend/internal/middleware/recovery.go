package middleware

import (
	"net/http"
	"runtime/debug"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"

	"backend/pkg/response"
)

// Recovery 全局异常捕获（第一层）：兜底任何 handler/middleware 里的 panic，
// 记录堆栈后按契约 §0 统一错误格式返回 500，保证进程不退出、连接不悬挂。
// 第二层在 pkg/response.Error：把服务层返回的 error 统一映射为业务错误/500。
func Recovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if r := recover(); r != nil {
				zap.L().Error("panic 已捕获",
					zap.Any("panic", r),
					zap.String("method", c.Request.Method),
					zap.String("path", c.Request.URL.Path),
					zap.ByteString("stack", debug.Stack()))
				if c.Writer.Written() {
					return // 响应已部分写出（如流式输出），无法再改写状态码
				}
				response.Err(c, http.StatusInternalServerError, "服务器内部错误")
			}
		}()
		c.Next()
	}
}
