package middleware

import (
	"net/http"

	"github.com/gin-gonic/gin"

	"backend/internal/config"
)

// CORS 跨域中间件（README M2 约定，契约附录"跨域与限流"）：
//   - mode=debug：放行所有 Origin（Apifox / 本地 H5 联调用）
//   - mode=release：收紧到 config.cors.allow_origins 白名单，名单外的请求
//     不带 Access-Control-Allow-Origin 头（浏览器侧表现为跨域失败）
//   - OPTIONS 预检统一 204 直接返回，不进业务逻辑
//
// 小程序请求本身不受 CORS 约束，本中间件主要服务于网页端与接口调试。
func CORS(cfg *config.Config) gin.HandlerFunc {
	allowAll := cfg.Mode != "release"
	whitelist := make(map[string]bool, len(cfg.CORS.AllowOrigins))
	for _, o := range cfg.CORS.AllowOrigins {
		whitelist[o] = true
	}
	return func(c *gin.Context) {
		if origin := c.GetHeader("Origin"); origin != "" {
			if allowAll || whitelist[origin] {
				c.Header("Access-Control-Allow-Origin", origin)
			}
			c.Header("Vary", "Origin")
			c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
			c.Header("Access-Control-Allow-Headers", "Authorization, Content-Type")
			c.Header("Access-Control-Max-Age", "86400")
		}
		if c.Request.Method == http.MethodOptions {
			c.AbortWithStatus(http.StatusNoContent)
			return
		}
		c.Next()
	}
}
