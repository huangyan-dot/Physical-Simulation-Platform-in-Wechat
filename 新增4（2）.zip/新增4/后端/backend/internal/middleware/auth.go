package middleware

import (
	"strings"

	"github.com/gin-gonic/gin"

	"backend/pkg/jwt"
	"backend/pkg/response"
)

// 请求上下文键：Auth 注入，controller/service 读取（与契约 §0 的鉴权约定配套）。
const (
	CtxUID  = "uid"
	CtxRole = "role"
)

// Auth JWT 鉴权中间件：校验 Authorization: Bearer <token>，成功则把 uid/role
// 注入请求上下文。失败统一 401（契约 §0：前端清登录态跳登录页）。
func Auth(secret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		token, ok := strings.CutPrefix(c.GetHeader("Authorization"), "Bearer ")
		if !ok || token == "" {
			response.Err(c, 401, "未登录（缺少 Bearer token）")
			c.Abort()
			return
		}
		claims, err := jwt.Parse(secret, token)
		if err != nil {
			response.Err(c, 401, "token 无效或已过期")
			c.Abort()
			return
		}
		c.Set(CtxUID, claims.UID)
		c.Set(CtxRole, claims.Role)
		c.Next()
	}
}

// RequireRole 角色守卫（README M2：敏感接口叠加在 Auth 之后），不符统一 403。
func RequireRole(roles ...string) gin.HandlerFunc {
	return func(c *gin.Context) {
		role := c.GetString(CtxRole)
		for _, r := range roles {
			if role == r {
				c.Next()
				return
			}
		}
		response.Err(c, 403, "无权限（角色不符）")
		c.Abort()
	}
}
