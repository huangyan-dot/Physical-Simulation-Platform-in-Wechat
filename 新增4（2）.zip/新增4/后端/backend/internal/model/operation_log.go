package model

import "time"

// OperationLog 操作审计表（契约 §13；M6 验收：登录/用户写操作均落审计）。
// v0.5 的两个复合索引一并建：idx_user_time(user_id, created_at) 按人查时间线、
// idx_action_time(action, created_at) 按动作查（如统计全部登录）。
type OperationLog struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	UserID    uint      `gorm:"index:idx_user_time,priority:1" json:"user_id"`        // 操作者
	Action    string    `gorm:"size:32;index:idx_action_time,priority:1" json:"action"` // login/user.create/user.update/user.delete/...
	LevelID   *uint     `json:"level_id"`                                              // 关卡 id（submit 类动作用）
	Score     *int      `json:"score"`                                                 // 得分（submit 类动作用）
	Detail    string    `gorm:"type:text" json:"detail"`                               // 人类可读审计明细
	CreatedAt time.Time `gorm:"index:idx_user_time,priority:2;index:idx_action_time,priority:2" json:"created_at"`
}
