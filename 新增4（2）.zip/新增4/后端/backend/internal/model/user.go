package model

import "time"

// User 用户表（契约 §1/§3：微信登录自动建号，name 为 NULL 表示学籍未补全）。
// 角色三档：student / teacher / admin（契约 §0 的 403 角色守卫依据）。
// 删除为物理删除：用户模块无软删字段，避免软删行占用 openid/student_no 唯一索引。
type User struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	OpenID    string    `gorm:"column:openid;size:64;uniqueIndex" json:"openid"` // 微信 openid，登录身份键，建号后不可改
	Role      string    `gorm:"size:16;index;default:student" json:"role"`        // student/teacher/admin
	Name      *string   `gorm:"size:64" json:"name"`                               // 姓名；NULL -> need_complete=true（契约 §1 补全模式）
	StudentNo *string   `gorm:"size:32;uniqueIndex" json:"student_no"`            // 学号，全库唯一，可空（未补全）
	ClassID   *uint     `json:"class_id"`                                           // 所在班级 id（班级表在权威仓库，此处仅存值）
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
}

// UserView 用户对外视图（契约 §1 的 user 对象，含 need_complete 派生字段；
// 管理类接口额外带 student_no/class_id/时间戳，均由本视图统一输出）。
type UserView struct {
	ID           uint      `json:"id"`
	OpenID       string    `json:"openid"`
	Role         string    `json:"role"`
	Name         *string   `json:"name"`
	StudentNo    *string   `json:"student_no"`
	ClassID      *uint     `json:"class_id"`
	NeedComplete bool      `json:"need_complete"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

// View 模型转视图：need_complete = 学籍未补全（name 为 NULL，契约 §1 前端切补全模式的判据）。
func (u *User) View() UserView {
	return UserView{
		ID:           u.ID,
		OpenID:       u.OpenID,
		Role:         u.Role,
		Name:         u.Name,
		StudentNo:    u.StudentNo,
		ClassID:      u.ClassID,
		NeedComplete: u.Name == nil,
		CreatedAt:    u.CreatedAt,
		UpdatedAt:    u.UpdatedAt,
	}
}
