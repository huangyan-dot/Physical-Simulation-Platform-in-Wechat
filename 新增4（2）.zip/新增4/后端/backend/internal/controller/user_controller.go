package controller

import (
	"strconv"

	"github.com/gin-gonic/gin"

	"backend/internal/middleware"
	"backend/internal/service"
	"backend/pkg/errs"
	"backend/pkg/response"
)

// UserController 用户模块 HTTP 层（契约 §19-§23）。
// 只做参数绑定、鉴权上下文读取与响应输出，不碰业务规则与 SQL。
type UserController struct {
	users *service.UserService
}

// NewUserController 构造（main 装配）。
func NewUserController(users *service.UserService) *UserController {
	return &UserController{users: users}
}

// Create POST /users（admin）新增用户，契约 §19。
//
//	请求体：{"openid":"...","role":"student","name":"...","student_no":"...","class_id":1}
//	响应 200：创建的用户视图；400 参数错；409 openid/学号重复
func (uc *UserController) Create(c *gin.Context) {
	var req service.CreateUserReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Err(c, 400, "请求体不是合法 JSON")
		return
	}
	view, err := uc.users.Create(c.Request.Context(), &req)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, view)
}

// Get GET /users/:id（JWT：本人或 teacher/admin）查询单个用户，契约 §20。
//
//	响应 200：用户视图；404 不存在；403 非本人且非教师/管理员
func (uc *UserController) Get(c *gin.Context) {
	id, err := parseID(c)
	if err != nil {
		response.Error(c, err)
		return
	}
	// 查看权限：本人 / teacher / admin（学籍隐私不向其他学生开放）
	uid, role := c.GetUint(middleware.CtxUID), c.GetString(middleware.CtxRole)
	if uid != id && role != "teacher" && role != "admin" {
		response.Err(c, 403, "无权限（仅本人或教师/管理员可查看）")
		return
	}
	view, err := uc.users.Get(c.Request.Context(), id)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, view)
}

// List GET /users（teacher/admin）用户列表，契约 §21。
//
//	Query：page（默认 1）、size（默认 50，上限 200）、role（可选）、keyword（可选，姓名/学号模糊）
//	响应 200：{page,size,total,records:[用户视图]}
func (uc *UserController) List(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1")) // 非数字按缺省，validatePage 归一
	size, _ := strconv.Atoi(c.DefaultQuery("size", "50"))
	q := service.ListUsersQuery{
		Page:    page,
		Size:    size,
		Role:    c.Query("role"),
		Keyword: c.Query("keyword"),
	}
	result, err := uc.users.List(c.Request.Context(), q)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, result)
}

// Update PUT /users/:id（JWT：本人改学籍字段；admin 可改全部含 role）修改用户，契约 §22。
//
//	请求体（部分更新，只改出现的字段）：{"name":"...","student_no":"...","class_id":1,"role":"teacher"}
//	响应 200：更新后的用户视图；400 参数错；403 改他人且非 admin；404 不存在
func (uc *UserController) Update(c *gin.Context) {
	id, err := parseID(c)
	if err != nil {
		response.Error(c, err)
		return
	}
	var req service.UpdateUserReq
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Err(c, 400, "请求体不是合法 JSON")
		return
	}
	uid, role := c.GetUint(middleware.CtxUID), c.GetString(middleware.CtxRole)
	if uid != id && role != "admin" {
		response.Err(c, 403, "无权限（只能修改本人信息，或由管理员修改）")
		return
	}
	view, err := uc.users.Update(c.Request.Context(), id, uid, role, &req)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, view)
}

// Delete DELETE /users/:id（admin）删除用户，契约 §23。
//
//	响应 200：{"message":"deleted"}；403 删除自己；404 不存在
func (uc *UserController) Delete(c *gin.Context) {
	id, err := parseID(c)
	if err != nil {
		response.Error(c, err)
		return
	}
	if err := uc.users.Delete(c.Request.Context(), id, c.GetUint(middleware.CtxUID)); err != nil {
		response.Error(c, err)
		return
	}
	response.Message(c, "deleted")
}

// OperationLogs GET /admin/operation-logs（admin）审计日志分页查询，契约 §13。
//
//	Query：user_id、action（均可选）、page（默认 1）、size（默认 50，上限 200）
//	响应 200：{page,size,total,records:[审计记录]}
func (uc *UserController) OperationLogs(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "1"))
	size, _ := strconv.Atoi(c.DefaultQuery("size", "50"))
	q := service.PageLogsQuery{Page: page, Size: size, Action: c.Query("action")}
	if uidStr := c.Query("user_id"); uidStr != "" {
		uid, err := strconv.ParseUint(uidStr, 10, 64)
		if err != nil || uid == 0 {
			response.Err(c, 400, "user_id 须为正整数")
			return
		}
		q.UserID = ptrUint(uint(uid))
	}
	result, err := uc.users.OperationLogs(c.Request.Context(), q)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, result)
}

// parseID 路径参数 :id -> uint（非正整数 400）。
func parseID(c *gin.Context) (uint, error) {
	id, err := strconv.ParseUint(c.Param("id"), 10, 64)
	if err != nil || id == 0 {
		return 0, errs.BadRequest("路径参数 id 须为正整数")
	}
	return uint(id), nil
}

// ptrUint 取指针（query 参数转指针字段用）。
func ptrUint(v uint) *uint { return &v }
