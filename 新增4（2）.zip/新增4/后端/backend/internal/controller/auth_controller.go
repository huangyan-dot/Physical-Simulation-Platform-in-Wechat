package controller

import (
	"github.com/gin-gonic/gin"

	"backend/internal/middleware"
	"backend/internal/service"
	"backend/pkg/response"
)

// AuthController 登录与当前用户（契约 §1/§2）。
type AuthController struct {
	auth *service.AuthService
}

// NewAuthController 构造（main 装配）。
func NewAuthController(auth *service.AuthService) *AuthController {
	return &AuthController{auth: auth}
}

// Login POST /auth/login（allow_dev_backdoor=true 时另有别名 POST /login），契约 §1。
//
//	请求体：{"code":"dev_student" 或微信临时 code}
//	响应 200：{"token":"...","user":{...}}；400 code 为空/微信侧校验失败
func (ac *AuthController) Login(c *gin.Context) {
	var req struct {
		Code string `json:"code"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		response.Err(c, 400, "请求体不是合法 JSON")
		return
	}
	resp, err := ac.auth.Login(c.Request.Context(), req.Code)
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, resp)
}

// Me GET /auth/me（JWT），契约 §2：返回当前登录用户视图。
func (ac *AuthController) Me(c *gin.Context) {
	view, err := ac.auth.Me(c.Request.Context(), c.GetUint(middleware.CtxUID))
	if err != nil {
		response.Error(c, err)
		return
	}
	response.OK(c, view)
}
