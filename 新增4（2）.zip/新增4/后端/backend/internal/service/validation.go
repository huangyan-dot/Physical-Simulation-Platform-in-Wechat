package service

import (
	"fmt"
	"strings"

	"backend/pkg/errs"
)

// ========== 入参校验（阶段5 数据校验增强，v0.15 用户模块沿用同一套约定）==========
//
// 校验一律在 service 层做（controller 只绑定参数不碰业务规则），返回 *errs.Error
// 直接映射为 400，错误消息面向前端可直接 toast。长度上限与建表 size 一致。

// validateClassName 班级名：trim 后非空且 <=64（v0.5 阶段5 约定，班级模块共用）。
func validateClassName(name string) error {
	name = strings.TrimSpace(name)
	if name == "" {
		return errs.BadRequest("班级名不能为空")
	}
	if len(name) > 64 {
		return errs.BadRequest("班级名长度不能超过 64")
	}
	return nil
}

// validateUserName 姓名：trim 后非空且 <=64（学籍补全 §3 同款规则；nil/空串由调用方判必填）。
func validateUserName(name string) error {
	name = strings.TrimSpace(name)
	if name == "" {
		return errs.BadRequest("姓名不能为空")
	}
	if len(name) > 64 {
		return errs.BadRequest("姓名长度不能超过 64")
	}
	return nil
}

// validateStudentNo 学号：trim 后非空且 <=32。
func validateStudentNo(no string) error {
	no = strings.TrimSpace(no)
	if no == "" {
		return errs.BadRequest("学号不能为空")
	}
	if len(no) > 32 {
		return errs.BadRequest("学号长度不能超过 32")
	}
	return nil
}

// validateRole 角色：三档之一（契约 §1：student/teacher/admin）。
func validateRole(role string) error {
	switch role {
	case "student", "teacher", "admin":
		return nil
	}
	return errs.BadRequest(fmt.Sprintf("角色非法: %q（须为 student/teacher/admin）", role))
}

// validateOpenID 微信 openid：trim 后非空且 <=64（与 users.openid 建表宽度一致）。
func validateOpenID(openid string) error {
	if openid == "" {
		return errs.BadRequest("openid 不能为空")
	}
	if len(openid) > 64 {
		return errs.BadRequest("openid 长度不能超过 64")
	}
	return nil
}

// validatePage 分页参数归一：page<1 回退 1；size<1 回退 50、超 200 钳到 200
// （默认值与上限沿用契约 §13 审计日志查询的约定）。
func validatePage(page, size int) (int, int) {
	if page < 1 {
		page = 1
	}
	if size < 1 {
		size = 50
	}
	if size > 200 {
		size = 200
	}
	return page, size
}
