package service

import (
	"context"
	"errors"
	"fmt"
	"strings"

	"go.uber.org/zap"
	"gorm.io/gorm"

	"backend/internal/model"
	"backend/internal/repository"
	"backend/pkg/errs"
)

// UserService 用户模块业务逻辑（v0.15 新增，契约 §19-§23）。
// controller 只做参数绑定与鉴权上下文读取，业务规则（权限、唯一性、学籍
// 字段白名单）全部在这里，便于单测与后续合并权威仓库。
type UserService struct {
	users *repository.UserRepository
	logs  *repository.LogRepository
}

// NewUserService 构造（main 装配：repo -> service -> controller）。
func NewUserService(users *repository.UserRepository, logs *repository.LogRepository) *UserService {
	return &UserService{users: users, logs: logs}
}

// CreateUserReq POST /users 请求体（admin 建号，契约 §19）。
type CreateUserReq struct {
	OpenID    string `json:"openid"`    // 必填，全库唯一
	Role      string `json:"role"`      // 缺省 student
	Name      string `json:"name"`      // 可选（不填则 need_complete=true）
	StudentNo string `json:"student_no"` // 可选，给出则须唯一
	ClassID   *uint  `json:"class_id"`  // 可选
}

// UpdateUserReq PUT /users/:id 请求体（契约 §22）：JSON 原生部分更新，只改出现的字段。
// 本人仅允许学籍字段（name/student_no/class_id），role 仅 admin（service 内强制）；
// 清空类操作（把 student_no 改回 null）暂不支持，字段不出现即保持不变。
type UpdateUserReq struct {
	Name      *string `json:"name"`
	StudentNo *string `json:"student_no"`
	ClassID   *uint   `json:"class_id"`
	Role      *string `json:"role"`
}

// ListUsersQuery GET /users 查询参数（契约 §21）。
type ListUsersQuery struct {
	Page    int
	Size    int
	Role    string   // 可选，精确过滤
	Keyword string   // 可选，name/student_no 模糊匹配
}

// PageLogsQuery 审计日志查询参数（契约 §13）。
type PageLogsQuery struct {
	Page   int
	Size   int
	UserID *uint  // 可选
	Action string // 可选
}

// PageResult 分页响应结构（契约 §13 的 {page,size,total,records}，用户列表复用同构）。
type PageResult[T any] struct {
	Page    int   `json:"page"`
	Size    int   `json:"size"`
	Total   int64 `json:"total"`
	Records []T   `json:"records"`
}

// Create 新增用户（admin）。openid 全库唯一（预检 409 + DB 唯一索引兜底并发），
// student_no 给出时同样须唯一。
func (s *UserService) Create(ctx context.Context, req *CreateUserReq) (*model.UserView, error) {
	req.OpenID = strings.TrimSpace(req.OpenID)
	if err := validateOpenID(req.OpenID); err != nil {
		return nil, err
	}
	if req.Role == "" {
		req.Role = "student" // 缺省学生，与登录自动建号一致
	}
	if err := validateRole(req.Role); err != nil {
		return nil, err
	}

	u := &model.User{OpenID: req.OpenID, Role: req.Role, ClassID: req.ClassID}
	if name := strings.TrimSpace(req.Name); name != "" {
		if err := validateUserName(name); err != nil {
			return nil, err
		}
		u.Name = &name
	}
	if no := strings.TrimSpace(req.StudentNo); no != "" {
		if err := validateStudentNo(no); err != nil {
			return nil, err
		}
		// 唯一性预检（并发窗口由 DB 唯一索引兜底）
		if existing, err := s.users.FindByStudentNo(ctx, no); err == nil && existing.ID != u.ID {
			return nil, errs.Conflict("学号已存在")
		} else if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, err
		}
		u.StudentNo = &no
	}
	if existing, err := s.users.FindByOpenID(ctx, req.OpenID); err == nil && existing.ID != u.ID {
		return nil, errs.Conflict("openid 已存在")
	} else if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	if err := s.users.Create(ctx, u); err != nil {
		if isDuplicateEntry(err) {
			return nil, errs.Conflict("openid 或学号已存在")
		}
		return nil, err
	}
	s.audit(ctx, u.ID, "user.create", fmt.Sprintf("openid=%s role=%s name=%s", u.OpenID, u.Role, deref(u.Name)))
	v := u.View()
	return &v, nil
}

// Get 查询单个用户（契约 §20）。查看权限（本人/teacher/admin）在 controller 判。
func (s *UserService) Get(ctx context.Context, id uint) (*model.UserView, error) {
	u, err := s.users.FindByID(ctx, id)
	if err != nil {
		return nil, mapUserErr(err)
	}
	v := u.View()
	return &v, nil
}

// List 用户列表（契约 §21，teacher/admin）：分页 + role/keyword 过滤。
func (s *UserService) List(ctx context.Context, q ListUsersQuery) (*PageResult[model.UserView], error) {
	q.Page, q.Size = validatePage(q.Page, q.Size)
	if q.Role != "" {
		if err := validateRole(q.Role); err != nil {
			return nil, err
		}
	}
	total, users, err := s.users.Page(ctx, repository.ListUsersQuery{
		Page:    q.Page,
		Size:    q.Size,
		Role:    q.Role,
		Keyword: strings.TrimSpace(q.Keyword),
	})
	if err != nil {
		return nil, err
	}
	records := make([]model.UserView, 0, len(users)) // 空页返回 [] 而非 null，前端遍历友好
	for i := range users {
		records = append(records, users[i].View())
	}
	return &PageResult[model.UserView]{Page: q.Page, Size: q.Size, Total: total, Records: records}, nil
}

// Update 修改用户（契约 §22，原 §3 学籍补全的超集）。规则：
//   - 本人：仅 name/student_no/class_id（学籍补全语义与原契约一致）
//   - admin：额外可改 role；openid 是登录身份键，一律不可改
func (s *UserService) Update(ctx context.Context, id, actorID uint, actorRole string, req *UpdateUserReq) (*model.UserView, error) {
	if req.Role != nil && actorRole != "admin" {
		return nil, errs.Forbidden("仅 admin 可修改角色")
	}
	u, err := s.users.FindByID(ctx, id)
	if err != nil {
		return nil, mapUserErr(err)
	}

	// 学籍字段逐项校验+应用（JSON 部分更新：未出现的字段不动）
	if req.Name != nil {
		name := strings.TrimSpace(*req.Name)
		if err := validateUserName(name); err != nil {
			return nil, err
		}
		u.Name = &name
	}
	if req.StudentNo != nil {
		no := strings.TrimSpace(*req.StudentNo)
		if err := validateStudentNo(no); err != nil {
			return nil, err
		}
		if existing, err := s.users.FindByStudentNo(ctx, no); err == nil && existing.ID != u.ID {
			return nil, errs.Conflict("学号已被其他用户使用")
		} else if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, err
		}
		u.StudentNo = &no
	}
	if req.ClassID != nil {
		u.ClassID = req.ClassID
	}
	if req.Role != nil {
		if err := validateRole(*req.Role); err != nil {
			return nil, err
		}
		u.Role = *req.Role
	}

	if err := s.users.Save(ctx, u); err != nil {
		if isDuplicateEntry(err) {
			return nil, errs.Conflict("学号已被其他用户使用")
		}
		return nil, err
	}
	s.audit(ctx, actorID, "user.update", fmt.Sprintf("target_user=%d name=%s role=%s", u.ID, deref(u.Name), u.Role))
	v := u.View()
	return &v, nil
}

// Delete 删除用户（契约 §23，admin）。物理删除；不允许删除当前登录账号自身
//（防管理员误删自己的管理入口）。
func (s *UserService) Delete(ctx context.Context, id, actorID uint) error {
	if id == actorID {
		return errs.Forbidden("不能删除当前登录账号")
	}
	u, err := s.users.FindByID(ctx, id)
	if err != nil {
		return mapUserErr(err)
	}
	if err := s.users.Delete(ctx, id); err != nil {
		return err
	}
	s.audit(ctx, actorID, "user.delete", fmt.Sprintf("target_user=%d openid=%s name=%s", u.ID, u.OpenID, deref(u.Name)))
	return nil
}

// OperationLogs 审计日志分页查询（契约 §13，admin）。
func (s *UserService) OperationLogs(ctx context.Context, q PageLogsQuery) (*PageResult[model.OperationLog], error) {
	q.Page, q.Size = validatePage(q.Page, q.Size)
	total, logs, err := s.logs.Page(ctx, repository.PageLogsQuery{
		Page:   q.Page,
		Size:   q.Size,
		UserID: q.UserID,
		Action: strings.TrimSpace(q.Action),
	})
	if err != nil {
		return nil, err
	}
	if logs == nil {
		logs = []model.OperationLog{} // 空页返回 [] 而非 null
	}
	return &PageResult[model.OperationLog]{Page: q.Page, Size: q.Size, Total: total, Records: logs}, nil
}

// ========== 内部工具 ==========

// mapUserErr 数据访问错误 -> 业务错误：not found 映射 404，其余原样上抛（500 兜底）。
func mapUserErr(err error) error {
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return errs.NotFound("用户不存在")
	}
	return err
}

// isDuplicateEntry MySQL 1062 唯一索引冲突（唯一性预检与写入之间的并发窗口兜底；
// GORM TranslateError 开启时为 gorm.ErrDuplicatedKey，关闭时回退错误串匹配）。
func isDuplicateEntry(err error) bool {
	return errors.Is(err, gorm.ErrDuplicatedKey) || strings.Contains(err.Error(), "Error 1062")
}

// audit 写操作审计（M6：用户写操作均落 operation_logs，action 命名沿用
// v0.5 的 user.create/user.update/user.delete 风格）。best-effort：失败仅记
// 告警日志，不让审计故障拖垮主流程。
func (s *UserService) audit(ctx context.Context, userID uint, action, detail string) {
	if err := s.logs.Create(ctx, &model.OperationLog{UserID: userID, Action: action, Detail: detail}); err != nil {
		zap.L().Warn("审计日志写入失败", zap.Uint("user_id", userID), zap.String("action", action), zap.Error(err))
	}
}

// deref 字符串指针安全取值（nil -> "<未设置>"，审计 detail 记录用）。
func deref(s *string) string {
	if s == nil {
		return "<未设置>"
	}
	return *s
}
