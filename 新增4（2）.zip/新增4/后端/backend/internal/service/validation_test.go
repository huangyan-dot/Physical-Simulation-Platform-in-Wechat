package service

import (
	"strings"
	"testing"
)

// ========== 入参校验单测（v0.15 用户模块；表驱动风格同 scoring_test.go）==========

func TestValidateUserName(t *testing.T) {
	cases := []struct {
		name string
		want bool // true = 合法
	}{
		{"李同学", true},
		{"  张三  ", true}, // trim 后非空
		{"", false},
		{"   ", false},
		{strings.Repeat("a", 64), true},  // 刚好 64
		{strings.Repeat("a", 65), false}, // 超 64
	}
	for _, c := range cases {
		if got := validateUserName(c.name) == nil; got != c.want {
			t.Errorf("validateUserName(%q): want ok=%v, got ok=%v", c.name, c.want, got)
		}
	}
}

func TestValidateStudentNo(t *testing.T) {
	cases := []struct {
		no   string
		want bool
	}{
		{"2023001", true},
		{"  2023001  ", true},
		{"", false},
		{"   ", false},
		{strings.Repeat("1", 32), true},
		{strings.Repeat("1", 33), false},
	}
	for _, c := range cases {
		if got := validateStudentNo(c.no) == nil; got != c.want {
			t.Errorf("validateStudentNo(%q): want ok=%v, got ok=%v", c.no, c.want, got)
		}
	}
}

func TestValidateRole(t *testing.T) {
	for _, r := range []string{"student", "teacher", "admin"} {
		if err := validateRole(r); err != nil {
			t.Errorf("validateRole(%q): want ok, got %v", r, err)
		}
	}
	for _, r := range []string{"", "root", "Student", "超级管理员"} {
		if err := validateRole(r); err == nil {
			t.Errorf("validateRole(%q): want error, got nil", r)
		}
	}
}

func TestValidateOpenID(t *testing.T) {
	cases := []struct {
		openid string
		want   bool
	}{
		{"oABCD1234", true},
		{"dev_student", true},
		{"", false},
		{strings.Repeat("o", 64), true},
		{strings.Repeat("o", 65), false},
	}
	for _, c := range cases {
		if got := validateOpenID(c.openid) == nil; got != c.want {
			t.Errorf("validateOpenID(%q): want ok=%v, got ok=%v", c.openid, c.want, got)
		}
	}
}

func TestValidatePage(t *testing.T) {
	// 缺省与钳制：page<1 回 1；size<1 回 50、超 200 钳 200（契约 §13 约定）
	cases := []struct{ page, size, wantPage, wantSize int }{
		{0, 0, 1, 50},
		{-1, -5, 1, 50},
		{3, 500, 3, 200},
		{2, 20, 2, 20},
	}
	for _, c := range cases {
		p, s := validatePage(c.page, c.size)
		if p != c.wantPage || s != c.wantSize {
			t.Errorf("validatePage(%d,%d): want (%d,%d), got (%d,%d)",
				c.page, c.size, c.wantPage, c.wantSize, p, s)
		}
	}
}
