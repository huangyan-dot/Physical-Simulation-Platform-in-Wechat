package service

import (
	"context"
	"errors"
	"strings"
	"time"

	"go.uber.org/zap"
	"gorm.io/gorm"

	"backend/internal/config"
	"backend/internal/model"
	"backend/internal/repository"
	"backend/pkg/errs"
	"backend/pkg/jwt"
	"backend/pkg/wechat"
)

// AuthService 登录与当前用户（契约 §1/§2）。
// 骨架重建说明：原项目已有此模块，本快照缺 main/router 等装配文件，
// 用户模块的鉴权（token 签发与 /auth/me）依赖它，故随 v0.15 一并补齐，
// 行为与契约 §1/§2 逐条对齐（dev 后门、首登自动建号、need_complete）。
type AuthService struct {
	users *repository.UserRepository
	logs  *repository.LogRepository
	cfg   *config.Config
}

// NewAuthService 构造（main 装配）。
func NewAuthService(users *repository.UserRepository, logs *repository.LogRepository, cfg *config.Config) *AuthService {
	return &AuthService{users: users, logs: logs, cfg: cfg}
}

// LoginResp POST /auth/login 响应（契约 §1）。
type LoginResp struct {
	Token string         `json:"token"`
	User  model.UserView `json:"user"`
}

// Login 微信登录。code 以 dev_ 开头且 allow_dev_backdoor=true 时走内置账号后门
//（不请求微信，README"开发后门开关"约定）；否则走 code2session 换 openid，
// 首次登录自动建号（student、name 为 NULL 即 need_complete=true）。
// 登录成功写一条 action=login 审计日志（v0.5 M6 约定）。
func (s *AuthService) Login(ctx context.Context, code string) (*LoginResp, error) {
	code = strings.TrimSpace(code)
	if code == "" {
		return nil, errs.BadRequest("code 不能为空")
	}

	var (
		u   *model.User
		err error
	)
	if strings.HasPrefix(code, "dev_") {
		if !s.cfg.AllowDevBackdoor {
			return nil, errs.BadRequest("dev 后门已关闭，请使用微信登录")
		}
		if u, err = s.users.FindByOpenID(ctx, code); err != nil {
			if errors.Is(err, gorm.ErrRecordNotFound) {
				return nil, errs.BadRequest("dev 账号不存在（启动 seed 应已写入 dev_student/dev_teacher/dev_admin）")
			}
			return nil, err
		}
	} else {
		openid, werr := wechat.Code2Session(s.cfg.WeChat.AppID, s.cfg.WeChat.Secret, code)
		if werr != nil {
			return nil, errs.BadRequest(werr.Error())
		}
		if u, err = s.users.FindByOpenID(ctx, openid); err != nil {
			if !errors.Is(err, gorm.ErrRecordNotFound) {
				return nil, err
			}
			// 首次登录自动建号：学生角色、学籍未补全
			u = &model.User{OpenID: openid, Role: "student"}
			if err = s.users.Create(ctx, u); err != nil {
				return nil, err
			}
		}
	}

	token, terr := jwt.Generate(s.cfg.JWT.Secret, u.ID, u.Role, time.Duration(s.cfg.JWT.ExpireHours)*time.Hour)
	if terr != nil {
		return nil, terr
	}
	// 审计 best-effort：失败不影响登录
	if lerr := s.logs.Create(ctx, &model.OperationLog{UserID: u.ID, Action: "login", Detail: "openid=" + u.OpenID}); lerr != nil {
		zap.L().Warn("审计日志写入失败", zap.Uint("user_id", u.ID), zap.String("action", "login"), zap.Error(lerr))
	}
	return &LoginResp{Token: token, User: u.View()}, nil
}

// Me 当前用户（契约 §2）：uid 由 middleware.Auth 从 token 解出注入。
// 账号已被删除但 token 未过期时返回 404（提示前端重新登录）。
func (s *AuthService) Me(ctx context.Context, uid uint) (*model.UserView, error) {
	u, err := s.users.FindByID(ctx, uid)
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, errs.NotFound("用户不存在（账号可能已被删除，请重新登录）")
		}
		return nil, err
	}
	v := u.View()
	return &v, nil
}
