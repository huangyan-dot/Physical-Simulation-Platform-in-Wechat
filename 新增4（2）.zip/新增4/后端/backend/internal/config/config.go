package config

import (
	"fmt"

	"github.com/spf13/viper"
)

// Config 全量配置（configs/config.yaml）。结构体字段与 yaml 键一一对应（mapstructure），
// 缺失键回退 setDefaults 的开发默认值，保证最小配置文件即可启动。
type Config struct {
	Mode             string `mapstructure:"mode"` // debug / release，影响 CORS 策略与 gin/日志模式
	Server           Server `mapstructure:"server"`
	MySQL            MySQL  `mapstructure:"mysql"`
	JWT              JWT    `mapstructure:"jwt"`
	WeChat           WeChat `mapstructure:"wechat"`
	CORS             CORS   `mapstructure:"cors"`
	AllowDevBackdoor bool   `mapstructure:"allow_dev_backdoor"`
}

// Server HTTP 服务配置。
type Server struct {
	Port int `mapstructure:"port"`
}

// MySQL 数据库连接配置（账号约定同 migrations/001：physics / physics123，非 root）。
type MySQL struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	User     string `mapstructure:"user"`
	Password string `mapstructure:"password"`
	Database string `mapstructure:"database"`
}

// DSN GORM MySQL DSN。charset/parseTime/loc 为 GORM time.Time 映射的必要参数，
// utf8mb4 与 001 建库参数一致（中文与 emoji）。
func (m MySQL) DSN() string {
	return fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		m.User, m.Password, m.Host, m.Port, m.Database)
}

// DSNNoDB 不带库名的 DSN（启动期幂等建库用，等价 001 的 CREATE DATABASE IF NOT EXISTS）。
func (m MySQL) DSNNoDB() string {
	return fmt.Sprintf("%s:%s@tcp(%s:%d)/?charset=utf8mb4&parseTime=True&loc=Local",
		m.User, m.Password, m.Host, m.Port)
}

// JWT 签发配置。
type JWT struct {
	Secret      string `mapstructure:"secret"`
	ExpireHours int    `mapstructure:"expire_hours"`
}

// WeChat 小程序登录配置（契约 §1 真实登录路径，开发期留空走 dev_ 后门）。
type WeChat struct {
	AppID  string `mapstructure:"appid"`
	Secret string `mapstructure:"secret"`
}

// CORS 跨域配置（仅 mode=release 生效的白名单；debug 放行所有 Origin）。
type CORS struct {
	AllowOrigins []string `mapstructure:"allow_origins"`
}

// Load 读取 configs/config.yaml（相对工作目录，即 backend/ 下启动）。
// 文件不存在或解析失败直接报错：配置是启动硬依赖，静默回退容易掩盖配置错误。
func Load() (*Config, error) {
	v := viper.New()
	v.SetConfigFile("configs/config.yaml")
	setDefaults(v)
	if err := v.ReadInConfig(); err != nil {
		return nil, fmt.Errorf("读取 configs/config.yaml 失败: %w", err)
	}
	var cfg Config
	if err := v.Unmarshal(&cfg); err != nil {
		return nil, fmt.Errorf("解析配置失败: %w", err)
	}
	return &cfg, nil
}

// setDefaults 全量开发默认值（与 configs/config.yaml 保持一致，yaml 缺键时兜底）。
func setDefaults(v *viper.Viper) {
	v.SetDefault("mode", "debug")
	v.SetDefault("server.port", 8080)
	v.SetDefault("mysql.host", "127.0.0.1")
	v.SetDefault("mysql.port", 3306)
	v.SetDefault("mysql.user", "physics")
	v.SetDefault("mysql.password", "physics123")
	v.SetDefault("mysql.database", "physics_lab")
	v.SetDefault("jwt.secret", "dev-secret-do-not-use-in-production")
	v.SetDefault("jwt.expire_hours", 72)
	v.SetDefault("wechat.appid", "")
	v.SetDefault("wechat.secret", "")
	v.SetDefault("cors.allow_origins", []string{})
	v.SetDefault("allow_dev_backdoor", true)
}
