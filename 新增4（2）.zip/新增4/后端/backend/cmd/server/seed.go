package main

import (
	"go.uber.org/zap"
	"gorm.io/gorm"

	"backend/internal/config"
	"backend/internal/model"
)

// seedAll 启动期幂等种子数据（README：dev 账号 / 示范班级；班级属权威仓库模块，此处只种 dev 账号）。
// 仅 allow_dev_backdoor=true 时写入；幂等：按 openid 查缺才建，不覆盖已有字段
//（避免重置线上已改过学籍的账号）。
func seedAll(db *gorm.DB, cfg *config.Config) {
	if !cfg.AllowDevBackdoor {
		zap.L().Info("allow_dev_backdoor=false，跳过 dev 账号种子")
		return
	}
	devAccounts := []model.User{
		{OpenID: "dev_student", Role: "student", Name: strPtr("测试同学"), StudentNo: strPtr("2023001")},
		{OpenID: "dev_teacher", Role: "teacher", Name: strPtr("张老师")},
		{OpenID: "dev_admin", Role: "admin", Name: strPtr("管理员")},
	}
	for _, u := range devAccounts {
		var cnt int64
		db.Model(&model.User{}).Where("openid = ?", u.OpenID).Count(&cnt)
		if cnt == 0 {
			if err := db.Create(&u).Error; err != nil {
				zap.L().Warn("dev 账号种子写入失败", zap.String("openid", u.OpenID), zap.Error(err))
			}
		}
	}
	zap.L().Info("种子数据就绪", zap.Int("dev_accounts", len(devAccounts)))
}

// strPtr 字符串取指针（种子数据便利函数）。
func strPtr(s string) *string { return &s }
