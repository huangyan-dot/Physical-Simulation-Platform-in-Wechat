package main

import (
	"fmt"
	"os"
	"time"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"

	"backend/internal/config"
	"backend/internal/controller"
	"backend/internal/middleware"
	"backend/internal/model"
	"backend/internal/repository"
	"backend/internal/router"
	"backend/internal/service"
)

// main 入口（README 目录结构约定）：加载配置 -> 连库 -> AutoMigrate -> seed ->
// 装配依赖（repository -> service -> controller -> router）-> 起服务。
// MySQL 不可用时降级为仅 /ping 可用（README 运行约定），进程不退出。
func main() {
	cfg, err := config.Load()
	if err != nil {
		fmt.Fprintln(os.Stderr, "启动失败:", err)
		os.Exit(1)
	}

	// 日志：debug 用 zap 开发模式（彩色+debug 级），release 用生产模式（json+info 级）
	var logger *zap.Logger
	if cfg.Mode == "release" {
		logger, _ = zap.NewProduction()
		gin.SetMode(gin.ReleaseMode)
	} else {
		logger, _ = zap.NewDevelopment()
	}
	defer logger.Sync()
	zap.ReplaceGlobals(logger)

	// 连库（重试若干次给本机 MySQL 启动留时间；失败则降级）
	db := mustInitDB(cfg)
	if db == nil {
		logger.Warn("MySQL 不可用，降级为仅 /ping 可用（请检查 configs/config.yaml 的 mysql 配置与本机 MySQL）")
		r := gin.New()
		r.Use(middleware.Recovery(), gin.Logger())
		r.GET("/ping", func(c *gin.Context) { c.JSON(200, gin.H{"message": "pong"}) })
		_ = r.Run(fmt.Sprintf(":%d", cfg.Server.Port))
		return
	}

	// AutoMigrate（README：亦可不跑 SQL，启动时自动建表）。
	// 本快照骨架只含用户模块两张表；experiments/levels 等由权威仓库的模型与 migration 自管。
	if err := db.AutoMigrate(&model.User{}, &model.OperationLog{}); err != nil {
		logger.Fatal("AutoMigrate 失败", zap.Error(err))
	}

	// 启动期幂等种子数据（dev 账号）
	seedAll(db, cfg)

	// 装配依赖：repository -> service -> controller -> router
	userRepo := repository.NewUserRepository(db)
	logRepo := repository.NewLogRepository(db)
	authCtrl := controller.NewAuthController(service.NewAuthService(userRepo, logRepo, cfg))
	userCtrl := controller.NewUserController(service.NewUserService(userRepo, logRepo))

	r := gin.New()
	router.Setup(r, cfg, authCtrl, userCtrl)

	logger.Info("服务启动", zap.Int("port", cfg.Server.Port), zap.String("mode", cfg.Mode),
		zap.Bool("dev_backdoor", cfg.AllowDevBackdoor))
	if err := r.Run(fmt.Sprintf(":%d", cfg.Server.Port)); err != nil {
		logger.Fatal("服务退出", zap.Error(err))
	}
}

// mustInitDB 连接 MySQL：先幂等建库（等价 001 的 CREATE DATABASE IF NOT EXISTS，
// 需 CREATE 权限，physics 账号无权限时仅告警并继续），再按 DSN 直连，
// 最多重试 5 次、每次间隔 2s（等待本机 MySQL 就绪）。全部失败返回 nil（降级）。
func mustInitDB(cfg *config.Config) *gorm.DB {
	if tmp, err := gorm.Open(mysql.Open(cfg.MySQL.DSNNoDB()), &gorm.Config{}); err == nil {
		if sqlDB, derr := tmp.DB(); derr == nil {
			_ = tmp.Exec(fmt.Sprintf(
				"CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci",
				cfg.MySQL.Database)).Error
			_ = sqlDB.Close()
		}
	} else {
		zap.L().Warn("建库预连接失败（继续尝试直连，若账号无 CREATE 权限属正常）", zap.Error(err))
	}

	for attempt := 1; attempt <= 5; attempt++ {
		db, err := gorm.Open(mysql.Open(cfg.MySQL.DSN()), &gorm.Config{
			TranslateError: true, // 1062 -> gorm.ErrDuplicatedKey，配合 service 层 409 语义
		})
		if err == nil {
			if sqlDB, perr := db.DB(); perr == nil {
				if perr = sqlDB.Ping(); perr == nil {
					return db
				}
				zap.L().Warn("MySQL ping 失败", zap.Int("attempt", attempt), zap.Error(perr))
			}
		} else {
			zap.L().Warn("MySQL 连接失败", zap.Int("attempt", attempt), zap.Error(err))
		}
		time.Sleep(2 * time.Second)
	}
	return nil
}
