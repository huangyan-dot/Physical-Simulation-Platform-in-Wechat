# 用户模块接口文档（v0.15 新增）

> 用户模块完整 CRUD（契约 §19-§23 的详版文档，配套 `docs/api-contract.md` v0.15）。
> 通用约定（Base URL、鉴权头、统一错误格式）见契约 §0，此处不重复。
> 所有写操作（新增/修改/删除）与登录均落 `operation_logs` 审计表（M6）。

## 0. 鉴权与角色

- 除 `POST /auth/login`、`GET /ping` 外均需请求头 `Authorization: Bearer <token>`
- token 由登录接口签发（HS256，载荷 uid+role，有效期默认 72h，见 `config.jwt`）
- 角色三档：`student` / `teacher` / `admin`；角色守卫不符返回 403

## 1. 登录（dev 后门）

`POST /auth/login`（`allow_dev_backdoor=true` 时另有别名 `POST /login`）

**请求**

```json
{ "code": "dev_admin" }
```

- `code` 以 `dev_` 开头走内置账号（`dev_student` / `dev_teacher` / `dev_admin`，启动 seed 幂等写入）
- 非 `dev_` 前缀走微信 code2session（需在 `config.yaml` 配置 `wechat.appid/secret`），首次登录自动建号（student）

**响应 200**

```json
{
  "token": "eyJhbGciOi...",
  "user": {
    "id": 3, "openid": "dev_admin", "role": "admin", "name": "管理员",
    "student_no": null, "class_id": null, "need_complete": false,
    "created_at": "2026-10-07T...", "updated_at": "2026-10-07T..."
  }
}
```

**错误**：400（code 为空 / dev 后门关闭 / 微信侧校验失败）

## 2. 当前用户

`GET /auth/me`（JWT）。响应 200：用户视图（同上 `user` 对象）。

## 3. 新增用户（§19）

`POST /users`（admin）

**请求**（`role` 缺省 `student`；`name`/`student_no`/`class_id` 可选）

```json
{ "openid": "oABC_test_001", "role": "student", "name": "王同学", "student_no": "2023099", "class_id": null }
```

**校验规则**（service 层，`internal/service/validation.go`）：

| 字段 | 规则 | 错误 |
|------|------|------|
| openid | trim 后非空、≤64、全库唯一 | 400 / 409 |
| role | student/teacher/admin 三档之一 | 400 |
| name | 可选；给出则 trim 后非空、≤64 | 400 |
| student_no | 可选；给出则 trim 后非空、≤32、全库唯一 | 400 / 409 |

**响应 200**：创建的用户视图（含 id）

**错误**：400 / 401 / 403（非 admin）/ 409（openid 或学号重复）

## 4. 查询单个用户（§20）

`GET /users/:id`（JWT：本人或 teacher/admin）

**响应 200**：用户视图（`need_complete` = 学籍未补全）

**错误**：400（id 非正整数）/ 403（非本人且非教师/管理员）/ 404

## 5. 列表查询（§21）

`GET /users`（teacher/admin）

**Query 参数**（均可选）：

| 参数 | 说明 |
|------|------|
| `page` | 页码，默认 1 |
| `size` | 每页条数，默认 50，上限 200 |
| `role` | 按角色精确过滤（student/teacher/admin） |
| `keyword` | 姓名/学号模糊匹配 |

**响应 200**（分页结构与审计日志查询 §13 同构）

```json
{
  "page": 1, "size": 50, "total": 4,
  "records": [
    { "id": 1, "openid": "dev_student", "role": "student", "name": "测试同学",
      "student_no": "2023001", "class_id": null, "need_complete": false,
      "created_at": "...", "updated_at": "..." }
  ]
}
```

**错误**：400（role 非法）/ 403（student 无权）

## 6. 修改用户（§22）

`PUT /users/:id`（JWT：本人可改学籍字段；admin 可改全部含 role）

**请求**（JSON 部分更新：只改出现的字段；`openid` 为登录身份键，一律不可改）

```json
{ "name": "李同学", "student_no": "2023001", "class_id": 1 }
```

admin 提额：

```json
{ "role": "teacher" }
```

**权限规则**：

| 操作者 | 可改字段 |
|--------|---------|
| 本人（uid == :id） | name / student_no / class_id（学籍补全，兼容原契约 §3 语义） |
| admin | 上述全部 + role |
| 其他 | 403 |

**校验规则**：同 §19 的字段表（出现在请求里的字段才校验与更新）；
`student_no` 变更时查重（409）。清空类操作（改回 null）暂不支持：字段不出现即保持不变。

**响应 200**：更新后的用户视图

**错误**：400 / 401 / 403 / 404 / 409

## 7. 删除用户（§23）

`DELETE /users/:id`（admin）

**响应 200**：`{ "message": "deleted" }`（契约 §6 风格；物理删除，无软删字段）

**错误**：403（非 admin / **删除当前登录账号自身**）/ 404

## 8. 审计日志查询（§13）

`GET /admin/operation-logs`（admin）

**Query**：`user_id`、`action`（如 `user.create`、`login`）、`page`、`size`

**响应 200**：`{page,size,total,records:[{id,user_id,action,level_id,score,detail,created_at}]}`

## 9. 跨域（CORS）

- `mode=debug`：放行所有 Origin（Apifox/H5 联调）
- `mode=release`：仅放行 `config.cors.allow_origins` 白名单
- OPTIONS 预检统一 204；`Access-Control-Allow-Headers: Authorization, Content-Type`

## 10. 全局异常与统一返回

- 成功响应直接返回数据本体；失败统一 `{"code": <HTTP状态码>, "message": "..."}`（契约 §0）
- 两层兜底：`middleware.Recovery` 捕获 panic -> 500；`pkg/response.Error` 把服务层
  `*errs.Error` 按其 code 响应、未知错误记 zap 后 500
