package jwt

import (
	"errors"
	"time"

	jwtlib "github.com/golang-jwt/jwt/v5"
)

// Claims 自定义载荷：uid + role（middleware.Auth 校验后注入请求上下文）。
type Claims struct {
	UID  uint   `json:"uid"`
	Role string `json:"role"`
	jwtlib.RegisteredClaims
}

// Generate 签发 HS256 token（契约 §0：Authorization: Bearer <token>）。
func Generate(secret string, uid uint, role string, ttl time.Duration) (string, error) {
	now := time.Now()
	claims := Claims{
		UID:  uid,
		Role: role,
		RegisteredClaims: jwtlib.RegisteredClaims{
			ExpiresAt: jwtlib.NewNumericDate(now.Add(ttl)),
			IssuedAt:  jwtlib.NewNumericDate(now),
		},
	}
	return jwtlib.NewWithClaims(jwtlib.SigningMethodHS256, claims).SignedString([]byte(secret))
}

// Parse 校验并解析 token。签名错/过期/格式错统一报错（调用方映射 401），
// 同时只接受 HMAC 系签名算法，防算法替换攻击。
func Parse(secret, tokenStr string) (*Claims, error) {
	var claims Claims
	token, err := jwtlib.ParseWithClaims(tokenStr, &claims, func(t *jwtlib.Token) (any, error) {
		if _, ok := t.Method.(*jwtlib.SigningMethodHMAC); !ok {
			return nil, errors.New("非法签名算法")
		}
		return []byte(secret), nil
	})
	if err != nil || !token.Valid {
		return nil, errors.New("token 无效或已过期")
	}
	return &claims, nil
}
