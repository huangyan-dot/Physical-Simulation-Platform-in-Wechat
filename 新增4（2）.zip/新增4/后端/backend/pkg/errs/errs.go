package errs

// Error 业务错误：Code 即 HTTP 状态码，与契约 §0 的统一错误格式对齐
// （HTTP 状态码与 body.code 一致，前端 request.js 按状态码判成败后 toast message）。
//
// 非业务错误（DB 故障、未预期异常）不包装成本类型，交给 pkg/response.Error
// 与 middleware.Recovery 统一兜底为 500，调用方无需逐处判断。
type Error struct {
	Code    int
	Message string
}

// Error 实现 error 接口（消息面向前端，可直接 toast）。
func (e *Error) Error() string { return e.Message }

// New 构造任意状态码的业务错误。
func New(code int, message string) *Error { return &Error{Code: code, Message: message} }

// 以下为契约 §0 的高频档位快捷构造（409 见 §7 的重复添加场景）。

// BadRequest 400 参数错误。
func BadRequest(message string) *Error { return New(400, message) }

// Unauthorized 401 未登录 / token 失效。
func Unauthorized(message string) *Error { return New(401, message) }

// Forbidden 403 无权限（角色不符 / 非本人）。
func Forbidden(message string) *Error { return New(403, message) }

// NotFound 404 资源不存在。
func NotFound(message string) *Error { return New(404, message) }

// Conflict 409 资源冲突（唯一键重复等）。
func Conflict(message string) *Error { return New(409, message) }

// Internal 500 服务器错误（一般不直接用，未知错误由全局兜底自动 500）。
func Internal(message string) *Error { return New(500, message) }
