package wechat

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"time"
)

// code2sessionURL 微信登录凭证校验接口（契约 §1 的真实登录路径）。
const code2sessionURL = "https://api.weixin.qq.com/sns/jscode2session"

// Code2Session 用 wx.login() 拿到的临时 code 换 openid。
// appid/secret 未配置时直接报错（开发期请走 dev_ 后门登录，上线前在 config.yaml 填好）。
func Code2Session(appid, secret, code string) (string, error) {
	if appid == "" || secret == "" {
		return "", fmt.Errorf("未配置微信 appid/secret，无法登录")
	}
	q := url.Values{
		"appid":      {appid},
		"secret":     {secret},
		"js_code":    {code},
		"grant_type": {"authorization_code"},
	}
	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Get(code2sessionURL + "?" + q.Encode())
	if err != nil {
		return "", fmt.Errorf("请求微信接口失败: %w", err)
	}
	defer resp.Body.Close()

	var body struct {
		OpenID  string `json:"openid"`
		ErrCode int    `json:"errcode"`
		ErrMsg  string `json:"errmsg"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		return "", fmt.Errorf("解析微信响应失败: %w", err)
	}
	if body.ErrCode != 0 {
		return "", fmt.Errorf("微信侧校验失败: %d %s", body.ErrCode, body.ErrMsg)
	}
	if body.OpenID == "" {
		return "", fmt.Errorf("微信响应缺少 openid")
	}
	return body.OpenID, nil
}
