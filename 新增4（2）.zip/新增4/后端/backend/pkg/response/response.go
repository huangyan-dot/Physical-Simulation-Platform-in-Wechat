package response

import (
	"errors"
	"net/http"

	"github.com/gin-gonic/gin"
	"go.uber.org/zap"

	"backend/pkg/errs"
)

// ========== 统一返回结果封装（契约 §0）==========
//
//   - 成功：直接返回数据本体（不包 {code:0,...}），前端按 HTTP 状态码判成败
//   - 失败：{"code": <HTTP状态码>, "message": "..."}，两处 code 保持一致
//
// 控制器一律通过本包写响应，禁止散落 c.JSON，保证全项目响应格式唯一。

// OK 200 成功响应（data 直接作为 body）。
func OK(c *gin.Context, data any) {
	c.JSON(http.StatusOK, data)
}

// Message 简单消息响应（契约 §6 风格：{"message":"deleted"}）。
func Message(c *gin.Context, msg string) {
	OK(c, gin.H{"message": msg})
}

// Err 统一错误响应：HTTP 状态码与 body.code 一致。
func Err(c *gin.Context, code int, message string) {
	c.JSON(code, gin.H{"code": code, "message": message})
}

// Error 错误统一出口——控制器/服务层返回的 error 一律走这里（全局异常捕获的第二层）：
//   - *errs.Error 业务错误：按其 Code/Message 响应（400/401/403/404/409...）
//   - 其余错误：视为服务端异常，记 zap 后返回 500（第一层 panic 兜底见 middleware.Recovery）
func Error(c *gin.Context, err error) {
	var be *errs.Error
	if errors.As(err, &be) {
		Err(c, be.Code, be.Message)
		return
	}
	zap.L().Error("未预期错误", zap.Error(err), zap.String("method", c.Request.Method), zap.String("path", c.Request.URL.Path))
	Err(c, http.StatusInternalServerError, "服务器内部错误")
}
