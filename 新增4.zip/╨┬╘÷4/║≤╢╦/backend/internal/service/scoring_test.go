package service

import (
	"fmt"
	"math"
	"strings"
	"testing"
)

func TestScoreByExperiment_EmptyReadingsIsError(t *testing.T) {
	// 契约 §12：readings 非法 -> 400。空数组必须返回 err（上层映射为 400）。
	for _, bad := range []string{`[]`, `{}`, `"x"`, `null`} {
		if _, _, _, err := scoreByExperiment("whatever", []byte(bad), []byte(`{}`), nil); err == nil {
			t.Fatalf("readings=%s: want error, got nil", bad)
		}
	}
}

func TestScoreByExperiment_UnknownExperimentIsError(t *testing.T) {
	if _, _, _, err := scoreByExperiment("nope", []byte(`[{"x":1}]`), []byte(`{}`), nil); err == nil {
		t.Fatal("unknown experiment code: want error, got nil")
	}
}

func TestValidateClassName(t *testing.T) {
	cases := []struct {
		name string
		want bool // true = 合法
	}{
		{"物理实验1班", true},
		{"  x  ", true}, // trim 后非空
		{"", false},
		{"   ", false},
		{strings.Repeat("a", 64), true},  // 刚好 64
		{strings.Repeat("a", 65), false}, // 超 64
	}
	for _, c := range cases {
		err := validateClassName(c.name)
		got := err == nil
		if got != c.want {
			t.Errorf("validateClassName(%q): want ok=%v, got ok=%v (err=%v)", c.name, c.want, got, err)
		}
	}
}

// ========== L1 二分法求根 ==========

// cubicTrueRoot x^3-x-1 在 [1.0,1.5] 的真值根（bisectRoot 双精度解）。
const cubicTrueRoot = 1.3247179572447460

const bisectionTarget = `{"method":"root_rel_err","func_key":"cubic_1","interval":[1.0,1.5],"pass_score":60}`

func submitBisection(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("bisection", []byte(readings), []byte(bisectionTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

func TestScoreBisection_CorrectRootFullScore(t *testing.T) {
	readings := fmt.Sprintf(`[{"root":%.16g,"iterations":19}]`, cubicTrueRoot)
	score, passed, detail := submitBisection(t, readings, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "iterations=19") {
		t.Errorf("detail 应记录 iterations: %s", detail)
	}
}

func TestScoreBisection_RelErrCurve(t *testing.T) {
	// 打分曲线拐点：相对误差恰为分段边界时的得分
	cases := []struct {
		relErr float64
		want   int
	}{
		{1e-6, 100},
		{1e-4, 90},
		{1e-3, 80},
		{1e-2, 65},
		{1e-1, 30},
		{0.03, 48}, // 拐点间 log 线性插值：65 - 35*log10(3) ≈ 48
	}
	for _, c := range cases {
		readings := fmt.Sprintf(`[{"root":%.17g}]`, cubicTrueRoot*(1+c.relErr))
		score, _, detail := submitBisection(t, readings, "")
		if score != c.want {
			t.Errorf("relErr=%.3g: want %d, got %d (detail=%s)", c.relErr, c.want, score, detail)
		}
	}
}

func TestScoreBisection_PassFail(t *testing.T) {
	// pass_score=60：relErr≈0.0139 是及格线（65-35*log10(relErr/1e-2)/1=60）
	for _, c := range []struct {
		relErr     float64
		wantPassed bool
	}{
		{0.012, true},
		{0.03, false},
		{0.25, false},
	} {
		readings := fmt.Sprintf(`[{"root":%.17g}]`, cubicTrueRoot*(1+c.relErr))
		_, passed, _ := submitBisection(t, readings, "")
		if passed != c.wantPassed {
			t.Errorf("relErr=%.3g: want passed=%v, got %v", c.relErr, c.wantPassed, passed)
		}
	}
}

func TestScoreBisection_UserConfigOverride(t *testing.T) {
	// v0.5 模式：前端换题 cos_x_x / [0,1]，真值根变为 0.739085...
	uc := `{"func_key":"cos_x_x","interval":[0.0,1.0]}`

	// 提交旧题（cubic_1）的根应不及格
	score, passed, _ := submitBisection(t, fmt.Sprintf(`[{"root":%.16g}]`, cubicTrueRoot), uc)
	if passed || score > 0 {
		t.Errorf("换题后旧根应 0 分不及格, got %d/%v", score, passed)
	}

	// 提交 cos_x_x 的正确根应满分
	score, passed, _ = submitBisection(t, `[{"root":0.7390851332151607}]`, uc)
	if score != 100 || !passed {
		t.Errorf("换题后正确根应 100/passed, got %d/%v", score, passed)
	}
}

func TestScoreBisection_MissingPassScoreAlwaysPasses(t *testing.T) {
	// 契约约定（002 注释）：target 缺 pass_score 时恒过关
	target := `{"method":"root_rel_err","func_key":"cubic_1","interval":[1.0,1.5]}`
	_, passed, detail, err := scoreByExperiment("bisection", []byte(`[{"root":2.0}]`), []byte(target), nil)
	if err != nil {
		t.Fatal(err)
	}
	if !passed {
		t.Errorf("缺 pass_score 应恒过关 (detail=%s)", detail)
	}
}

func TestScoreBisection_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, target string
	}{
		{"缺 root 字段", `[{"iterations":19}]`, bisectionTarget},
		{"root 非法 JSON", `[{"root":NaN}]`, bisectionTarget},
		{"readings 元素非对象", `[1.3]`, bisectionTarget},
		{"未知函数", `[{"root":1.3}]`, `{"method":"root_rel_err","func_key":"nope","interval":[1.0,1.5]}`},
		{"区间不夹根", `[{"root":1.3}]`, `{"method":"root_rel_err","func_key":"cubic_1","interval":[2.0,3.0]}`},
		{"区间逆序", `[{"root":1.3}]`, `{"method":"root_rel_err","func_key":"cubic_1","interval":[1.5,1.0]}`},
		{"target 非法 JSON", `[{"root":1.3}]`, `{`},
	}
	for _, c := range cases {
		if _, _, _, err := scoreByExperiment("bisection", []byte(c.readings), []byte(c.target), nil); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

// ========== L2 牛顿迭代法求根 ==========

const newtonTarget = `{"method":"newton_rel_err","func_key":"cubic_1","interval":[1.0,1.5],"x0":1.5,"tolerance":1e-6,"max_iterations":50,"pass_score":60}`

func submitNewton(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("newton_iter", []byte(readings), []byte(newtonTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

func TestScoreNewtonIter_CorrectFastConvergence(t *testing.T) {
	// x0=1.5、|x_{n+1}-x_n|<1e-6 准则下牛顿 4 步收敛（二分要 19 步）
	score, passed, detail := submitNewton(t, `[{"root":1.324717957244746,"iterations":4,"x0":1.5}]`, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "expected_iterations=4") {
		t.Errorf("detail 应含 expected_iterations=4: %s", detail)
	}
}

func TestScoreNewtonIter_BisectionPaddingPenalized(t *testing.T) {
	// 根正确但报 19 次迭代（二分法冒充）：罚 4x(19-4-2)=52 -> 48 不及格
	score, passed, detail := submitNewton(t, `[{"root":1.324717957244746,"iterations":19,"x0":1.5}]`, "")
	if score != 48 || passed {
		t.Fatalf("want 48/not-passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "penalty=52") {
		t.Errorf("detail 应含 penalty=52: %s", detail)
	}
}

func TestScoreNewtonIter_RootErrOnly(t *testing.T) {
	// 根偏 0.4% 但迭代数正常：沿用打分曲线 71 分
	score, passed, _ := submitNewton(t, `[{"root":1.33,"iterations":5,"x0":1.5}]`, "")
	if score != 71 || !passed {
		t.Fatalf("want 71/passed, got %d/%v", score, passed)
	}
}

func TestScoreNewtonIter_ChangeFuncSqrt2(t *testing.T) {
	// 换题 sqrt_2：正初值收敛到 +√2
	score, passed, detail := submitNewton(t, `[{"root":1.4142135623730951,"iterations":5}]`, `{"func_key":"sqrt_2","x0":1.0}`)
	if score != 100 || !passed {
		t.Fatalf("sqrt_2 正初值: want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	// 负初值收敛到 -√2，按学生实际路径评分（不是死对 target 区间正根）
	score, passed, detail = submitNewton(t, `[{"root":-1.4142135623730951,"iterations":5}]`, `{"func_key":"sqrt_2","x0":-1.0}`)
	if score != 100 || !passed {
		t.Fatalf("sqrt_2 负初值: want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
}

func TestScoreNewtonIter_ZeroDerivativeFallsBackToBisect(t *testing.T) {
	// x0=0 时 f'(0)=2x=0，牛顿中断 -> 回退 target 区间 [1,1.5] 二分真值 √2，且不罚迭代分
	score, passed, detail := submitNewton(t, `[{"root":1.4142135623730951,"iterations":5,"x0":0}]`, `{"func_key":"sqrt_2"}`)
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if strings.Contains(detail, "expected_iterations") {
		t.Errorf("回退路径不应有 expected_iterations: %s", detail)
	}
}

func TestScoreNewtonIter_FallbackNoBracketIsError(t *testing.T) {
	// 牛顿中断（x0=0, f'=0）且兜底区间不夹根 -> 400
	target := `{"method":"newton_rel_err","func_key":"sqrt_2","interval":[2.0,3.0],"x0":0,"tolerance":1e-6,"max_iterations":50,"pass_score":60}`
	if _, _, _, err := scoreByExperiment("newton_iter", []byte(`[{"root":1.41,"iterations":5}]`), []byte(target), nil); err == nil {
		t.Fatal("牛顿中断且区间不夹根: want error, got nil")
	}
}

func TestScoreNewtonIter_BadInput(t *testing.T) {
	cases := []struct {
		name, readings string
	}{
		{"缺 root", `[{"iterations":5}]`},
		{"root 非法 JSON", `[{"root":NaN}]`},
		{"iterations 为 0", `[{"root":1.324718,"iterations":0}]`},
		{"iterations 超 max", `[{"root":1.324718,"iterations":51}]`},
		{"x0 非法 JSON", `[{"root":1.324718,"x0":abc}]`},
	}
	for _, c := range cases {
		if _, _, _, err := scoreByExperiment("newton_iter", []byte(c.readings), []byte(newtonTarget), nil); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
	// 未知函数
	if _, _, _, err := scoreByExperiment("newton_iter", []byte(`[{"root":1.3}]`), []byte(`{"method":"newton_rel_err","func_key":"nope","interval":[1.0,1.5],"x0":1.5}`), nil); err == nil {
		t.Error("未知函数: want error, got nil")
	}
}

// ========== L3 高斯消去法解线性方程组 ==========

const gaussTarget = `{"method":"linear_rel_err","system_key":"sys3_basic","pass_score":60}`

func submitGauss(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("gauss_elim", []byte(readings), []byte(gaussTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

func TestScoreGaussElim_ExactSolution(t *testing.T) {
	// sys3_basic 真值解恰为整数 (2, 3, -1)
	score, passed, detail := submitGauss(t, `[{"solution":[2,3,-1]}]`, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "system=sys3_basic") || !strings.Contains(detail, "n=3") {
		t.Errorf("detail 应记录 system 与 n: %s", detail)
	}
}

func TestScoreGaussElim_RelErrCurve(t *testing.T) {
	// 真值 [2,3,-1]，||x*||inf=3；在 x1 上注入偏差，relErr = 偏差/3
	cases := []struct {
		name string
		sol  string
		want int
	}{
		{"偏差 1e-7 -> 100", `[{"solution":[2.0000001,3,-1]}]`, 100}, // relErr≈3.3e-8
		{"偏差 0.003 -> 80", `[{"solution":[2.003,3,-1]}]`, 80},      // relErr=1e-3 拐点
		{"偏差 0.3 -> 30", `[{"solution":[2.3,3,-1]}]`, 30},          // relErr=0.1 拐点
		{"全错 -> 0", `[{"solution":[5,6,7]}]`, 0},                   // relErr=8/3
	}
	for _, c := range cases {
		score, _, _ := submitGauss(t, c.sol, "")
		if score != c.want {
			t.Errorf("%s: want %d, got %d", c.name, c.want, score)
		}
	}
}

func TestScoreGaussElim_UserConfigSystemKey(t *testing.T) {
	// 换库内方程组 sys4_tridiag，真值解 [1,-1,2,0.5]
	score, passed, _ := submitGauss(t, `[{"solution":[1,-1,2,0.5]}]`, `{"system_key":"sys4_tridiag"}`)
	if score != 100 || !passed {
		t.Fatalf("换题后正确解: want 100/passed, got %d/%v", score, passed)
	}
	// 换题后仍交旧解（补 0 凑 4 维）-> relErr=4/2=2 -> 0 分（防背答案）
	score, _, _ = submitGauss(t, `[{"solution":[2,3,-1,0]}]`, `{"system_key":"sys4_tridiag"}`)
	if score != 0 {
		t.Fatalf("换题后旧解: want 0, got %d", score)
	}
}

func TestScoreGaussElim_UserConfigCustomMatrix(t *testing.T) {
	// 前端自定义方程组 x+y=3, x-y=1 -> 解 [2,1]（A/b 优先于 system_key）
	score, _, _ := submitGauss(t, `[{"solution":[2,1]}]`, `{"A":[[1,1],[1,-1]],"b":[3,1]}`)
	if score != 100 {
		t.Fatalf("自定义方程组正确解: want 100, got %d", score)
	}
}

func TestScoreGaussElim_HilbertStability(t *testing.T) {
	// 4x4 Hilbert 病态矩阵：列主元消去双精度真值解与精确解全 1 差 ~1e-12
	score, _, detail := submitGauss(t, `[{"solution":[1,1,1,1]}]`, `{"system_key":"hilbert4"}`)
	if score != 100 {
		t.Fatalf("hilbert4 精确解: want 100, got %d (detail=%s)", score, detail)
	}
}

func TestScoreGaussElim_BandsOverride(t *testing.T) {
	// target.bands 覆盖默认曲线：5% 内满分（物理量级容差演示）
	target := `{"method":"linear_rel_err","system_key":"sys3_basic","pass_score":60,"bands":[[0.05,100],[0.5,60],[2,0]]}`
	// solution [2.5,3,-1]：relErr=0.5/3≈0.167，log10 插值 100-40*log10(3.33)≈79
	score, _, _, _ := scoreByExperiment("gauss_elim", []byte(`[{"solution":[2.5,3,-1]}]`), []byte(target), nil)
	if score != 79 {
		t.Fatalf("bands 覆盖: want 79, got %d", score)
	}
}

func TestScoreGaussElim_SingularMatrixIsError(t *testing.T) {
	// 奇异矩阵（第 2 行 = 2 x 第 1 行）-> 400
	_, _, _, err := scoreByExperiment("gauss_elim", []byte(`[{"solution":[1,2]}]`),
		[]byte(gaussTarget), []byte(`{"A":[[1,2],[2,4]],"b":[3,6]}`))
	if err == nil {
		t.Fatal("奇异矩阵: want error, got nil")
	}
}

func TestScoreGaussElim_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, userConfig string
	}{
		{"缺 solution", `[{"root":1}]`, ""},
		{"solution 长度不匹配", `[{"solution":[2,3]}]`, ""},
		{"solution 含 NaN", `[{"solution":[2,3,NaN]}]`, ""},
		{"非法 JSON", `[{"solution":abc}]`, ""},
		{"未知方程组", `[{"solution":[2,3,-1]}]`, `{"system_key":"nope"}`},
		{"自定义 1 阶", `[{"solution":[1]}]`, `{"A":[[1]],"b":[1]}`},
		{"自定义 9 阶", `[{"solution":[1,2,3,4,5,6,7,8,9]}]`, `{"A":[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],"b":[1,2,3,4,5,6,7,8,9]}`},
		{"自定义缺 b", `[{"solution":[2,1]}]`, `{"A":[[1,1],[1,-1]]}`},
		{"自定义非方阵", `[{"solution":[2,1]}]`, `{"A":[[1,1,2],[1,-1,3]],"b":[3,1]}`},
	}
	for _, c := range cases {
		uc := []byte(nil)
		if c.userConfig != "" {
			uc = []byte(c.userConfig)
		}
		if _, _, _, err := scoreByExperiment("gauss_elim", []byte(c.readings), []byte(gaussTarget), uc); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

// ========== L4 雅可比迭代法解线性方程组 ==========

const jacobiTarget = `{"method":"jacobi_rel_err","system_key":"sys3_diagdom","x0":[0,0,0],"tolerance":1e-6,"max_iterations":100,"pass_score":60}`

func submitJacobi(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("jacobi_iter", []byte(readings), []byte(jacobiTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

// jacobiExpected 后端模拟 sys3_diagdom 从零向量的雅可比迭代数（罚分基准，约 14 步）。
func jacobiExpected(t *testing.T) int {
	t.Helper()
	def := linSystems["sys3_diagdom"]
	x, k, err := jacobiSolve(def.A, def.b, nil, 1e-6, 100)
	if err != nil || len(x) != 3 {
		t.Fatalf("jacobiSolve: err=%v len=%d", err, len(x))
	}
	return k
}

func TestScoreJacobiIter_ExactSolution(t *testing.T) {
	// sys3_diagdom 真值解恰为整数 (1, 2, 3)
	score, passed, detail := submitJacobi(t, `[{"solution":[1,2,3]}]`, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "system=sys3_diagdom") || !strings.Contains(detail, "n=3") {
		t.Errorf("detail 应记录 system 与 n: %s", detail)
	}
}

func TestScoreJacobiIter_HonestIterationsNoPenalty(t *testing.T) {
	exp := jacobiExpected(t)
	// 如实报期望迭代数：不罚
	readings := fmt.Sprintf(`[{"solution":[1,2,3],"iterations":%d}]`, exp)
	if score, _, detail := submitJacobi(t, readings, ""); score != 100 {
		t.Fatalf("期望迭代数不罚: want 100, got %d (detail=%s)", score, detail)
	}
	// 高斯-赛德尔量级（约一半）：合法实现，也不罚
	readings = fmt.Sprintf(`[{"solution":[1,2,3],"iterations":%d}]`, exp/2)
	if score, _, detail := submitJacobi(t, readings, ""); score != 100 {
		t.Fatalf("半量迭代不罚: want 100, got %d (detail=%s)", score, detail)
	}
}

func TestScoreJacobiIter_DirectMethodPenalized(t *testing.T) {
	// 直接消去得精确解后冒充 1 次雅可比迭代 -> 罚 4 x (expected/2 - 3)
	exp := jacobiExpected(t)
	want := 100 - 4*(exp/2-2-1)
	score, _, detail := submitJacobi(t, `[{"solution":[1,2,3],"iterations":1}]`, "")
	if score != want {
		t.Fatalf("want %d, got %d (detail=%s)", want, score, detail)
	}
	if !strings.Contains(detail, "penalty=") {
		t.Errorf("detail 应记录 penalty: %s", detail)
	}
}

func TestScoreJacobiIter_RelErrCurve(t *testing.T) {
	// 真值 [1,2,3]，||x*||inf=3；在 x1 上注入偏差，relErr = 偏差/3
	cases := []struct {
		name string
		sol  string
		want int
	}{
		{"偏差 0.003 -> 80", `[{"solution":[1.003,2,3]}]`, 80}, // relErr=1e-3 拐点
		{"偏差 0.03 -> 65", `[{"solution":[1.03,2,3]}]`, 65},   // relErr=1e-2 拐点
		{"偏差 0.3 -> 30", `[{"solution":[1.3,2,3]}]`, 30},     // relErr=0.1 拐点
		{"全错 -> 0", `[{"solution":[4,5,6]}]`, 0},             // relErr=1
	}
	for _, c := range cases {
		score, _, _ := submitJacobi(t, c.sol, "")
		if score != c.want {
			t.Errorf("%s: want %d, got %d", c.name, c.want, score)
		}
	}
}

func TestScoreJacobiIter_UserConfigSystemKey(t *testing.T) {
	// 换 sys4_tridiag（对角占优，雅可比同样收敛），真值解 [1,-1,2,0.5]
	score, passed, _ := submitJacobi(t, `[{"solution":[1,-1,2,0.5]}]`, `{"system_key":"sys4_tridiag"}`)
	if score != 100 || !passed {
		t.Fatalf("换题后正确解: want 100/passed, got %d/%v", score, passed)
	}
	// 换题后仍交原方程组的解（补 0 凑 4 维）-> relErr=4/2=2 -> 0 分（防背答案）
	score, _, _ = submitJacobi(t, `[{"solution":[1,2,3,0]}]`, `{"system_key":"sys4_tridiag"}`)
	if score != 0 {
		t.Fatalf("换题后旧解: want 0, got %d", score)
	}
}

func TestScoreJacobiIter_UserConfigCustomMatrix(t *testing.T) {
	// 前端自定义对角占优方程组 5x+y=6, x+4y=5 -> 解 [1,1]
	score, _, _ := submitJacobi(t, `[{"solution":[1,1]}]`, `{"A":[[5,1],[1,4]],"b":[6,5]}`)
	if score != 100 {
		t.Fatalf("自定义方程组正确解: want 100, got %d", score)
	}
}

func TestScoreJacobiIter_NonConvergentNoExpectedNoPenalty(t *testing.T) {
	// 非对角占优自定义系统：后端模拟不收敛 -> 无期望迭代数、不罚分，仍按精度计分
	score, _, detail := submitJacobi(t, `[{"solution":[2,1],"iterations":1}]`, `{"A":[[1,1],[1,-1]],"b":[3,1]}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if strings.Contains(detail, "expected_iterations") {
		t.Errorf("不应有 expected_iterations: %s", detail)
	}
}

func TestScoreJacobiIter_ReadingsX0(t *testing.T) {
	// 初值即真值：后端从同一 x0 模拟，期望迭代数=1，如实报 1 次不罚
	score, _, detail := submitJacobi(t, `[{"solution":[1,2,3],"iterations":1,"x0":[1,2,3]}]`, "")
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "x0=[1,2,3]") {
		t.Errorf("detail 应记录 x0: %s", detail)
	}
}

func TestScoreJacobiIter_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, userConfig string
	}{
		{"缺 solution", `[{"root":1}]`, ""},
		{"solution 长度不匹配", `[{"solution":[1,2]}]`, ""},
		{"solution 含 NaN", `[{"solution":[1,2,NaN]}]`, ""},
		{"非法 JSON", `[{"solution":abc}]`, ""},
		{"未知方程组", `[{"solution":[1,2,3]}]`, `{"system_key":"nope"}`},
		{"自定义 1 阶", `[{"solution":[1]}]`, `{"A":[[1]],"b":[1]}`},
		{"自定义 9 阶", `[{"solution":[1,2,3,4,5,6,7,8,9]}]`, `{"A":[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],"b":[1,2,3,4,5,6,7,8,9]}`},
		{"自定义非方阵", `[{"solution":[2,1]}]`, `{"A":[[1,1,2],[1,-1,3]],"b":[3,1]}`},
		{"自定义奇异", `[{"solution":[1,2]}]`, `{"A":[[1,2],[2,4]],"b":[3,6]}`},
		{"自定义零对角元", `[{"solution":[1,2]}]`, `{"A":[[0,1],[1,2]],"b":[2,5]}`},
		{"自定义缺 b", `[{"solution":[2,1]}]`, `{"A":[[5,1],[1,4]]}`},
		{"iterations 为 0", `[{"solution":[1,2,3],"iterations":0}]`, ""},
		{"iterations 超上限", `[{"solution":[1,2,3],"iterations":101}]`, ""},
		{"readings x0 长度错", `[{"solution":[1,2,3],"x0":[0,0]}]`, ""},
	}
	for _, c := range cases {
		uc := []byte(nil)
		if c.userConfig != "" {
			uc = []byte(c.userConfig)
		}
		if _, _, _, err := scoreByExperiment("jacobi_iter", []byte(c.readings), []byte(jacobiTarget), uc); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

// ========== L5 SOR 逐次超松弛迭代法解线性方程组 ==========

const sorTarget = `{"method":"sor_rel_err","system_key":"sys6_poisson","x0":[0,0,0,0,0,0],"omega":1.0,"tolerance":1e-6,"max_iterations":100,"pass_score":60}`

func submitSor(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("sor_iter", []byte(readings), []byte(sorTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

// sorExpected 后端模拟 sys6_poisson 从零向量、给定 ω 的 SOR 迭代数（罚分基准）。
// ω=1（高斯-赛德尔）约 61 步，ω≈1.4 最优约 19 步；雅可比要 114 步（超 100 上限不收敛）。
func sorExpected(t *testing.T, omega float64) int {
	t.Helper()
	def := linSystems["sys6_poisson"]
	x, k, err := sorSolve(def.A, def.b, nil, omega, 1e-6, 100)
	if err != nil || len(x) != 6 {
		t.Fatalf("sorSolve(omega=%g): err=%v len=%d", omega, err, len(x))
	}
	return k
}

func TestScoreSorIter_ExactSolution(t *testing.T) {
	// sys6_poisson 真值解为全 1（一维泊松方程差分，边界驱动）
	score, passed, detail := submitSor(t, `[{"solution":[1,1,1,1,1,1]}]`, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "system=sys6_poisson") || !strings.Contains(detail, "n=6") || !strings.Contains(detail, "omega=1") {
		t.Errorf("detail 应记录 system/n/omega: %s", detail)
	}
}

func TestScoreSorIter_HonestIterationsNoPenalty(t *testing.T) {
	// 如实报期望迭代数：不罚
	readings := fmt.Sprintf(`[{"solution":[1,1,1,1,1,1],"iterations":%d}]`, sorExpected(t, 1.0))
	if score, _, detail := submitSor(t, readings, ""); score != 100 {
		t.Fatalf("期望迭代数不罚: want 100, got %d (detail=%s)", score, detail)
	}
}

func TestScoreSorIter_OptimalOmegaFasterNoPenalty(t *testing.T) {
	// SOR 核心教学点：ω≈1.4 最优松弛因子把 61 步压到 ~19 步；
	// 期望迭代数按学生提交的 ω 现算，换 ω 后如实报数不罚
	exp := sorExpected(t, 1.4)
	if exp > 25 {
		t.Fatalf("ω=1.4 应约 19 步（<=25），got %d", exp)
	}
	readings := fmt.Sprintf(`[{"solution":[1,1,1,1,1,1],"iterations":%d,"omega":1.4}]`, exp)
	score, _, detail := submitSor(t, readings, "")
	if score != 100 {
		t.Fatalf("最优 ω 如实报数: want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "omega=1.4") {
		t.Errorf("detail 应记录学生 ω: %s", detail)
	}
	// ω 记在 user_config 同样生效（前端滑块换 ω 后经 user_config 提交）
	readings = fmt.Sprintf(`[{"solution":[1,1,1,1,1,1],"iterations":%d}]`, exp)
	if score, _, _ := submitSor(t, readings, `{"omega":1.4}`); score != 100 {
		t.Fatalf("user_config.omega: want 100, got %d", score)
	}
}

func TestScoreSorIter_GaussSeidelFakeFastConvergencePenalized(t *testing.T) {
	// ω=1（高斯-赛德尔）却只报 19 步（仅最优 ω 可达）-> 罚 4 x (61/2 - 2 - 19) = 36
	exp := sorExpected(t, 1.0)
	want := 100 - 4*(exp/2 - 2 - 19)
	if want < 0 {
		want = 0
	}
	score, _, detail := submitSor(t, `[{"solution":[1,1,1,1,1,1],"iterations":19}]`, "")
	if score != want {
		t.Fatalf("want %d, got %d (detail=%s)", want, score, detail)
	}
	if !strings.Contains(detail, "penalty=") {
		t.Errorf("detail 应记录 penalty: %s", detail)
	}
}

func TestScoreSorIter_DirectMethodPenalized(t *testing.T) {
	// 直接消去得精确解后冒充 1 次 SOR 迭代 -> 罚 4 x (expected/2 - 2 - 1)
	exp := sorExpected(t, 1.0)
	want := 100 - 4*(exp/2 - 2 - 1)
	if want < 0 {
		want = 0
	}
	score, _, detail := submitSor(t, `[{"solution":[1,1,1,1,1,1],"iterations":1}]`, "")
	if score != want {
		t.Fatalf("want %d, got %d (detail=%s)", want, score, detail)
	}
	if !strings.Contains(detail, "penalty=") {
		t.Errorf("detail 应记录 penalty: %s", detail)
	}
}

func TestScoreSorIter_RelErrCurve(t *testing.T) {
	// 真值全 1，||x*||inf=1；在 x1 上注入偏差，relErr = 偏差
	cases := []struct {
		name string
		sol  string
		want int
	}{
		{"偏差 1e-3 -> 80", `[{"solution":[1.001,1,1,1,1,1]}]`, 80},  // relErr=1e-3 拐点
		{"偏差 1e-2 -> 65", `[{"solution":[1.01,1,1,1,1,1]}]`, 65},   // relErr=1e-2 拐点
		{"偏差 0.1 -> 30", `[{"solution":[1.1,1,1,1,1,1]}]`, 30},     // relErr=0.1 拐点
		{"全错 -> 0", `[{"solution":[2,2,2,2,2,2]}]`, 0},             // relErr=1
	}
	for _, c := range cases {
		score, _, _ := submitSor(t, c.sol, "")
		if score != c.want {
			t.Errorf("%s: want %d, got %d", c.name, c.want, score)
		}
	}
}

func TestScoreSorIter_UserConfigSystemKey(t *testing.T) {
	// 换 sys3_diagdom（对角占优，SOR 同样收敛），真值解 [1,2,3]；
	// target.x0 为 6 维与 3 阶系统不符，应静默回退零向量而非报错
	score, passed, _ := submitSor(t, `[{"solution":[1,2,3]}]`, `{"system_key":"sys3_diagdom"}`)
	if score != 100 || !passed {
		t.Fatalf("换题后正确解: want 100/passed, got %d/%v", score, passed)
	}
	// 换题后仍交原方程组的全 1 解 -> relErr=2/3 -> 0 分（防背答案）
	score, _, _ = submitSor(t, `[{"solution":[1,1,1]}]`, `{"system_key":"sys3_diagdom"}`)
	if score != 0 {
		t.Fatalf("换题后旧解: want 0, got %d", score)
	}
}

func TestScoreSorIter_UserConfigCustomMatrix(t *testing.T) {
	// 前端自定义对角占优方程组 5x+y=6, x+4y=5 -> 解 [1,1]，带 ω=1.2
	score, _, detail := submitSor(t, `[{"solution":[1,1],"omega":1.2}]`, `{"A":[[5,1],[1,4]],"b":[6,5]}`)
	if score != 100 {
		t.Fatalf("自定义方程组正确解: want 100, got %d (detail=%s)", score, detail)
	}
}

func TestScoreSorIter_NonConvergentNoExpectedNoPenalty(t *testing.T) {
	// 非对角占优自定义系统：后端模拟不收敛 -> 无期望迭代数、不罚分，仍按精度计分
	score, _, detail := submitSor(t, `[{"solution":[2,1],"iterations":1}]`, `{"A":[[1,1],[1,-1]],"b":[3,1]}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if strings.Contains(detail, "expected_iterations") {
		t.Errorf("不应有 expected_iterations: %s", detail)
	}
}

func TestScoreSorIter_OverRelaxTooBigNoConvergenceNoPenalty(t *testing.T) {
	// ω 过大（1.95）：收敛半径 0.95，100 步内不收敛 -> 无期望、不罚分，按精度计分
	score, _, detail := submitSor(t, `[{"solution":[1,1,1,1,1,1],"iterations":50,"omega":1.95}]`, "")
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if strings.Contains(detail, "expected_iterations") {
		t.Errorf("不应有 expected_iterations: %s", detail)
	}
}

func TestScoreSorIter_ReadingsX0(t *testing.T) {
	// 初值即真值：后端从同一 x0 模拟，期望迭代数=1，如实报 1 次不罚
	score, _, detail := submitSor(t, `[{"solution":[1,1,1,1,1,1],"iterations":1,"x0":[1,1,1,1,1,1]}]`, "")
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "x0=[1,1,1,1,1,1]") {
		t.Errorf("detail 应记录 x0: %s", detail)
	}
}

func TestScoreSorIter_OmegaPriorityReadingsOverUserConfig(t *testing.T) {
	// readings.omega 优先于 user_config.omega：期望按 readings 的 1.3 现算
	score, _, detail := submitSor(t, `[{"solution":[1,1,1,1,1,1],"omega":1.3}]`, `{"omega":1.4}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "omega=1.3") {
		t.Errorf("readings.omega 应优先: %s", detail)
	}
}

func TestScoreSorIter_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, userConfig string
	}{
		{"缺 solution", `[{"root":1}]`, ""},
		{"solution 长度不匹配", `[{"solution":[1,1,1]}]`, ""},
		{"solution 含 NaN", `[{"solution":[1,1,1,1,1,NaN]}]`, ""},
		{"非法 JSON", `[{"solution":abc}]`, ""},
		{"未知方程组", `[{"solution":[1,1,1,1,1,1]}]`, `{"system_key":"nope"}`},
		{"自定义 1 阶", `[{"solution":[1]}]`, `{"A":[[1]],"b":[1]}`},
		{"自定义 9 阶", `[{"solution":[1,2,3,4,5,6,7,8,9]}]`, `{"A":[[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]],"b":[1,2,3,4,5,6,7,8,9]}`},
		{"自定义非方阵", `[{"solution":[2,1]}]`, `{"A":[[1,1,2],[1,-1,3]],"b":[3,1]}`},
		{"自定义奇异", `[{"solution":[1,2]}]`, `{"A":[[1,2],[2,4]],"b":[3,6]}`},
		{"自定义零对角元", `[{"solution":[1,2]}]`, `{"A":[[0,1],[1,2]],"b":[2,5]}`},
		{"自定义缺 b", `[{"solution":[2,1]}]`, `{"A":[[5,1],[1,4]]}`},
		{"iterations 为 0", `[{"solution":[1,1,1,1,1,1],"iterations":0}]`, ""},
		{"iterations 超上限", `[{"solution":[1,1,1,1,1,1],"iterations":101}]`, ""},
		{"readings x0 长度错", `[{"solution":[1,1,1,1,1,1],"x0":[0,0]}]`, ""},
		{"omega 为 0", `[{"solution":[1,1,1,1,1,1],"omega":0}]`, ""},
		{"omega 为 2", `[{"solution":[1,1,1,1,1,1],"omega":2}]`, ""},
		{"omega 超界 2.5", `[{"solution":[1,1,1,1,1,1],"omega":2.5}]`, ""},
		{"omega 为负", `[{"solution":[1,1,1,1,1,1],"omega":-0.5}]`, ""},
		{"user_config omega 非法", `[{"solution":[1,1,1,1,1,1]}]`, `{"omega":3}`},
	}
	for _, c := range cases {
		uc := []byte(nil)
		if c.userConfig != "" {
			uc = []byte(c.userConfig)
		}
		if _, _, _, err := scoreByExperiment("sor_iter", []byte(c.readings), []byte(sorTarget), uc); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

// ========== L6 拉格朗日插值 ==========

const lagrangeTarget = `{"method":"interp_rel_err","problem_key":"sin_quad","pass_score":60}`

func submitLagrange(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("lagrange_interp", []byte(readings), []byte(lagrangeTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

// interpTrueP 运行时算库内题真值 P(x_eval)（测试与评分共用同一 lagrangeEval，
// 另以 sin_quad 的手工闭式解交叉验证，防"自己证自己"）。
func interpTrueP(t *testing.T, key string, xEval float64) float64 {
	t.Helper()
	def := interpProblems[key]
	if xEval != xEval { // NaN -> 用库内默认求值点
		xEval = def.XEval
	}
	p, err := lagrangeEval(def.Xs, def.Ys, xEval)
	if err != nil {
		t.Fatalf("lagrangeEval(%s, %g): %v", key, xEval, err)
	}
	return p
}

func TestScoreLagrangeInterp_ExactSolution(t *testing.T) {
	// sin_quad P(π/6) = (4√2−1)/9 ≈ 0.517428（闭式解交叉验证）
	wantP := (4*math.Sqrt2 - 1) / 9
	got := interpTrueP(t, "sin_quad", math.Pi/6)
	if math.Abs(got-wantP) > 1e-12 {
		t.Fatalf("sin_quad 真值: want %.12g, got %.12g", wantP, got)
	}
	readings := fmt.Sprintf(`[{"value":%.12g,"basis":[%.12g,%.12g,%.12g]}]`,
		got, 2.0/9, 8.0/9, -1.0/9)
	score, passed, detail := submitLagrange(t, readings, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "problem=sin_quad") || !strings.Contains(detail, "n=3") {
		t.Errorf("detail 应记录 problem/n: %s", detail)
	}
	if !strings.Contains(detail, "basis=[0.222222,0.888889,-0.111111]") {
		t.Errorf("detail 应记录 basis: %s", detail)
	}
}

func TestScoreLagrangeInterp_RelErrCurve(t *testing.T) {
	p := interpTrueP(t, "sin_quad", math.NaN())
	for _, c := range []struct {
		relErr float64
		want   int
	}{
		{1e-7, 100},
		{1e-4, 90},
		{1e-3, 80},
		{1e-2, 65},
		{0.1, 30},
		{0.5, 0},
	} {
		readings := fmt.Sprintf(`[{"value":%.12g}]`, p*(1+c.relErr))
		if score, _, _ := submitLagrange(t, readings, ""); score != c.want {
			t.Errorf("rel_err=%g: want %d, got %d", c.relErr, c.want, score)
		}
	}
}

func TestScoreLagrangeInterp_RungeAntiCheat(t *testing.T) {
	// 龙格现象题：P(0.8) ≈ −0.379310 而 f(0.8) = 1/17 ≈ 0.058824。
	// 不做插值直接抄原函数值 -> 相对误差 ~1.15 -> 0 分（插值实验天然防抄函数值）
	p := interpTrueP(t, "runge_5", math.NaN())
	if p >= 0 {
		t.Fatalf("runge_5 P(0.8) 应为负（龙格振荡），got %g", p)
	}
	if score, _, _ := submitLagrange(t, fmt.Sprintf(`[{"value":%.12g}]`, p), `{"problem_key":"runge_5"}`); score != 100 {
		t.Fatalf("插值真值: want 100, got %d", score)
	}
	if score, passed, _ := submitLagrange(t, fmt.Sprintf(`[{"value":%.12g}]`, 1.0/17), `{"problem_key":"runge_5"}`); score != 0 || passed {
		t.Fatalf("抄 f 值: want 0/not passed, got %d/%v", score, passed)
	}
}

func TestScoreLagrangeInterp_UserConfigProblemKey(t *testing.T) {
	// 换题 sqrt_table：教材经典，P(115) ≈ 10.722756（vs √115 ≈ 10.723805）
	p := interpTrueP(t, "sqrt_table", math.NaN())
	if math.Abs(p-10.722756) > 1e-6 {
		t.Fatalf("sqrt_table P(115): want ~10.722756, got %g", p)
	}
	score, _, detail := submitLagrange(t, fmt.Sprintf(`[{"value":%.12g}]`, p), `{"problem_key":"sqrt_table"}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "problem=sqrt_table") {
		t.Errorf("detail 应记录换题后的 problem: %s", detail)
	}
}

func TestScoreLagrangeInterp_UserConfigCustomNodes(t *testing.T) {
	// 自定义 3 节点 (0,0),(1,1),(2,4) 插 x²，P(0.5) = 0.25
	score, _, detail := submitLagrange(t, `[{"value":0.25}]`, `{"nodes_x":[0,1,2],"nodes_y":[0,1,4],"x_eval":0.5}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "problem=custom") {
		t.Errorf("detail 应记录 problem=custom: %s", detail)
	}
	// 自定义节点数上下限：1 个 / 9 个 -> 错
	if _, _, _, err := scoreByExperiment("lagrange_interp", []byte(`[{"value":1}]`), []byte(lagrangeTarget), []byte(`{"nodes_x":[1],"nodes_y":[2],"x_eval":1}`)); err == nil {
		t.Error("单节点应报错")
	}
}

func TestScoreLagrangeInterp_UserConfigXEval(t *testing.T) {
	// 覆盖求值点：sin_quad 节点上求值 P(π/4) = √2/2（插值多项式过节点）
	if score, _, _ := submitLagrange(t, fmt.Sprintf(`[{"value":%.12g}]`, math.Sqrt2/2), `{"x_eval":0.7853981633974483}`); score != 100 {
		t.Fatalf("节点处求值: want 100, got %d", score)
	}
	// 非节点处 x_eval=π/3，真值运行时算
	p := interpTrueP(t, "sin_quad", math.Pi/3)
	if score, _, _ := submitLagrange(t, fmt.Sprintf(`[{"value":%.12g}]`, p), `{"x_eval":1.0471975511965976}`); score != 100 {
		t.Fatalf("x_eval 覆盖: want 100, got %d", score)
	}
}

func TestScoreLagrangeInterp_BasisAudit(t *testing.T) {
	// basis 可选：值随意不参与打分，只须长度=节点数且有限，记入审计 detail
	score, _, detail := submitLagrange(t, `[{"value":0.5174281,"basis":[1,2,3]}]`, "")
	if score != 100 {
		t.Fatalf("basis 不影响打分: want 100, got %d", score)
	}
	if !strings.Contains(detail, "basis=[1,2,3]") {
		t.Errorf("detail 应原样记录 basis: %s", detail)
	}
}

func TestScoreLagrangeInterp_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, userConfig string
	}{
		{"缺 value", `[{"basis":[1,2,3]}]`, ""},
		{"value 为 NaN", `[{"value":NaN}]`, ""},
		{"非法 JSON", `[{"value":abc}]`, ""},
		{"basis 长度错", `[{"value":0.5,"basis":[1,2]}]`, ""},
		{"basis 含 NaN", `[{"value":0.5,"basis":[1,NaN,3]}]`, ""},
		{"未知插值题", `[{"value":0.5}]`, `{"problem_key":"nope"}`},
		{"自定义缺 x_eval", `[{"value":0.5}]`, `{"nodes_x":[0,1,2],"nodes_y":[0,1,4]}`},
		{"自定义 x 重复", `[{"value":0.5}]`, `{"nodes_x":[1,1,2],"nodes_y":[0,1,4],"x_eval":1.5}`},
		{"自定义 x/y 不匹配", `[{"value":0.5}]`, `{"nodes_x":[0,1,2],"nodes_y":[0,1],"x_eval":1.5}`},
		{"自定义节点数 9", `[{"value":0.5}]`, `{"nodes_x":[1,2,3,4,5,6,7,8,9],"nodes_y":[1,2,3,4,5,6,7,8,9],"x_eval":5}`},
	}
	for _, c := range cases {
		uc := []byte(nil)
		if c.userConfig != "" {
			uc = []byte(c.userConfig)
		}
		if _, _, _, err := scoreByExperiment("lagrange_interp", []byte(c.readings), []byte(lagrangeTarget), uc); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

func TestScoreLagrangeInterp_TargetXEvalOnlyForTargetProblem(t *testing.T) {
	// target 带 sin_quad 的求值点（真库 target 即如此）；user_config 换 runge_5
	// 不带 x_eval 时，应用 runge_5 库内默认 0.8，而非沿用 target 的 0.5236
	// （target 的 x_eval 只属于 target 自己的题）。v0.12.1 修复。
	tgt := `{"method":"interp_rel_err","problem_key":"sin_quad","x_eval":0.5235987755982988,"pass_score":60}`
	p := interpTrueP(t, "runge_5", math.NaN()) // 库内默认 0.8
	score, _, _, err := scoreByExperiment("lagrange_interp",
		[]byte(fmt.Sprintf(`[{"value":%.12g}]`, p)), []byte(tgt), []byte(`{"problem_key":"runge_5"}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 100 {
		t.Fatalf("换题不带 x_eval 应用库内默认求值点: want 100, got %d", score)
	}
	// 抄 f(0.8)=1/17 应 0 分（相对误差 ~1.15，e2e 曾因此 bug 误判 14 分）
	score, _, _, err = scoreByExperiment("lagrange_interp",
		[]byte(`[{"value":0.0588235294}]`), []byte(tgt), []byte(`{"problem_key":"runge_5"}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 0 {
		t.Fatalf("换题后抄 f 值: want 0, got %d", score)
	}
	// 换题且显式给 x_eval 时按给定值（0.5 是 runge_5 节点，P=f(0.5)=4/29）
	score, _, _, err = scoreByExperiment("lagrange_interp",
		[]byte(fmt.Sprintf(`[{"value":%.12g}]`, 4.0/29)), []byte(tgt), []byte(`{"problem_key":"runge_5","x_eval":0.5}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 100 {
		t.Fatalf("换题+显式 x_eval: want 100, got %d", score)
	}
}

// ========== L17 复合辛普森积分 ==========

const simpsonTarget = `{"method":"integ_rel_err","problem_key":"sin_pi","pass_score":60}`

func submitSimpson(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("simpson_integration", []byte(readings), []byte(simpsonTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

// simpsonTrueS 运行时算库内题真值 S_n（测试与评分共用同一 compositeSimpson，
// 各题另以手工闭式解交叉验证，防"自己证自己"）。
func simpsonTrueS(t *testing.T, key string, n int) float64 {
	t.Helper()
	def := integProblems[key]
	if n <= 0 {
		n = def.N
	}
	return compositeSimpson(def.F, def.A, def.B, n)
}

func TestScoreSimpsonIntegration_ExactSolution(t *testing.T) {
	// sin_pi n=2 单次辛普森闭式：S = (π/6)(0+4·1+0) = 2π/3 ≈ 2.094395（交叉验证）
	wantS := 2 * math.Pi / 3
	got := simpsonTrueS(t, "sin_pi", 2)
	if math.Abs(got-wantS) > 1e-12 {
		t.Fatalf("sin_pi S_2: want %.12g, got %.12g", wantS, got)
	}
	readings := fmt.Sprintf(`[{"value":%.12g,"odd_sum":1,"even_sum":0}]`, got)
	score, passed, detail := submitSimpson(t, readings, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "problem=sin_pi") || !strings.Contains(detail, "n=2") {
		t.Errorf("detail 应记录 problem/n: %s", detail)
	}
	if !strings.Contains(detail, "odd_sum=1") || !strings.Contains(detail, "even_sum=0") {
		t.Errorf("detail 应记录 odd/even_sum: %s", detail)
	}
	if !strings.Contains(detail, "ref_I=2") {
		t.Errorf("detail 应记录参考积分 ref_I: %s", detail)
	}
}

func TestScoreSimpsonIntegration_RelErrCurve(t *testing.T) {
	s := simpsonTrueS(t, "sin_pi", 2)
	for _, c := range []struct {
		relErr float64
		want   int
	}{
		{1e-7, 100},
		{1e-4, 90},
		{1e-3, 80},
		{1e-2, 65},
		{0.1, 30},
		{0.5, 0},
	} {
		readings := fmt.Sprintf(`[{"value":%.12g}]`, s*(1+c.relErr))
		if score, _, _ := submitSimpson(t, readings, ""); score != c.want {
			t.Errorf("rel_err=%g: want %d, got %d", c.relErr, c.want, score)
		}
	}
}

func TestScoreSimpsonIntegration_ExactIntegralTrap(t *testing.T) {
	// 不算辛普森直接抄精确积分 I=2：|2−2π/3|/(2π/3) ≈ 4.5% -> ~42 分不过线
	// （真值是"方法的输出"S_n 而非精确积分，同 L16 真值=P 而非 f 的设计）
	score, passed, _ := submitSimpson(t, `[{"value":2}]`, "")
	if passed || score >= 60 {
		t.Fatalf("抄精确积分值: want <60/not passed, got %d/%v", score, passed)
	}
}

func TestScoreSimpsonIntegration_UserConfigProblemKey(t *testing.T) {
	// 换题 erf_gauss n=4：I=(√π/2)·erf(1) 无初等闭式必须数值积分；
	// S_4 手工闭式 (1/12)(1 + 4(e^{−1/16}+e^{−9/16}) + 2e^{−1/4} + e^{−1}) 交叉验证
	wantS := (1.0 + 4*(math.Exp(-1.0/16)+math.Exp(-9.0/16)) + 2*math.Exp(-0.25) + math.Exp(-1)) / 12
	got := simpsonTrueS(t, "erf_gauss", 4)
	if math.Abs(got-wantS) > 1e-12 {
		t.Fatalf("erf_gauss S_4: want %.12g, got %.12g", wantS, got)
	}
	score, _, detail := submitSimpson(t, fmt.Sprintf(`[{"value":%.12g}]`, got), `{"problem_key":"erf_gauss"}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "problem=erf_gauss") {
		t.Errorf("detail 应记录换题后的 problem: %s", detail)
	}
	// 抄精确积分 I ≈ 0.746824：n=4 截断误差小，只得低分但不至于 0（防白嫖满分）
	iErf := math.Sqrt(math.Pi) / 2 * 0.8427007929497149 // erf(1)
	if score, _, _ := submitSimpson(t, fmt.Sprintf(`[{"value":%.12g}]`, iErf), `{"problem_key":"erf_gauss"}`); score >= 100 {
		t.Fatalf("抄精确积分应 <100, got %d", score)
	}

	// 换题 sqrt_x n=8：端点导数奇异收敛慢，S_8 ≈ 0.663079 vs I=2/3（差 3.6e-3）
	got = simpsonTrueS(t, "sqrt_x", 8)
	if math.Abs(got-0.6630793) > 1e-6 {
		t.Fatalf("sqrt_x S_8: want ~0.6630793, got %g", got)
	}
	if score, _, _ := submitSimpson(t, fmt.Sprintf(`[{"value":%.12g}]`, got), `{"problem_key":"sqrt_x"}`); score != 100 {
		t.Fatalf("sqrt_x 正确 S_8: want 100")
	}
	if score, _, _ := submitSimpson(t, `[{"value":0.6666666666666666}]`, `{"problem_key":"sqrt_x"}`); score >= 100 {
		t.Fatalf("sqrt_x 抄精确积分应 <100, got %d", score)
	}
}

func TestScoreSimpsonIntegration_UserConfigN(t *testing.T) {
	// 加密分段 n=8：真值同步变为 S_8（更接近 I=2），正确算仍 100 分
	s8 := simpsonTrueS(t, "sin_pi", 8)
	s2 := simpsonTrueS(t, "sin_pi", 2)
	if math.Abs(s8-2) >= math.Abs(s2-2) {
		t.Fatalf("n=8 应比 n=2 更接近精确积分: |S8-2|=%g |S2-2|=%g", math.Abs(s8-2), math.Abs(s2-2))
	}
	score, _, detail := submitSimpson(t, fmt.Sprintf(`[{"value":%.12g}]`, s8), `{"n":8}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "n=8") {
		t.Errorf("detail 应记录 n=8: %s", detail)
	}
}

func TestScoreSimpsonIntegration_UserConfigInterval(t *testing.T) {
	// 换区间 [0,π/2] n=2：S = (π/12)(4·sin(π/4) + 1) = (π/12)(2√2+1)（闭式交叉验证）
	wantS := (2*math.Sqrt2 + 1) * math.Pi / 12
	got := compositeSimpson(math.Sin, 0, math.Pi/2, 2)
	if math.Abs(got-wantS) > 1e-12 {
		t.Fatalf("[0,π/2] S_2: want %.12g, got %.12g", wantS, got)
	}
	score, _, detail := submitSimpson(t, fmt.Sprintf(`[{"value":%.12g}]`, got), `{"a":0,"b":1.5707963267948966}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "b=1.5708") {
		t.Errorf("detail 应记录区间: %s", detail)
	}
}

func TestScoreSimpsonIntegration_SumsAudit(t *testing.T) {
	// odd_sum/even_sum 可选：值随意不参与打分，只须有限，记入审计 detail
	score, _, detail := submitSimpson(t, `[{"value":2.0943951023931953,"odd_sum":3.14,"even_sum":-2}]`, "")
	if score != 100 {
		t.Fatalf("odd/even_sum 不影响打分: want 100, got %d", score)
	}
	if !strings.Contains(detail, "odd_sum=3.14") || !strings.Contains(detail, "even_sum=-2") {
		t.Errorf("detail 应原样记录 odd/even_sum: %s", detail)
	}
}

func TestScoreSimpsonIntegration_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, userConfig string
	}{
		{"缺 value", `[{"odd_sum":1}]`, ""},
		{"value 为 NaN", `[{"value":NaN}]`, ""},
		{"非法 JSON", `[{"value":abc}]`, ""},
		{"odd_sum 为 NaN", `[{"value":2,"odd_sum":NaN}]`, ""},
		{"未知积分题", `[{"value":2}]`, `{"problem_key":"nope"}`},
		{"n 为奇数", `[{"value":2}]`, `{"n":3}`},
		{"n=1", `[{"value":2}]`, `{"n":1}`},
		{"n 超上限", `[{"value":2}]`, `{"n":1026}`},
		{"区间 a>=b", `[{"value":2}]`, `{"a":1,"b":1}`},
		{"区间只给 a", `[{"value":2}]`, `{"a":0.5}`},
	}
	for _, c := range cases {
		uc := []byte(nil)
		if c.userConfig != "" {
			uc = []byte(c.userConfig)
		}
		if _, _, _, err := scoreByExperiment("simpson_integration", []byte(c.readings), []byte(simpsonTarget), uc); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

func TestScoreSimpsonIntegration_TargetParamsOnlyForTargetProblem(t *testing.T) {
	// target 带 sin_pi 的区间/n（真库 target 即如此）；user_config 换 sqrt_x
	// 不带区间/n 时，应用 sqrt_x 库内默认 [0,1] n=8，而非沿用 target 的
	//（target 的题专属参数只属于 target 自己的题，v0.12.1 求值点归属规则同款）
	tgt := `{"method":"integ_rel_err","problem_key":"sin_pi","a":0,"b":3.141592653589793,"n":2,"pass_score":60}`
	s8 := simpsonTrueS(t, "sqrt_x", 8)
	score, _, _, err := scoreByExperiment("simpson_integration",
		[]byte(fmt.Sprintf(`[{"value":%.12g}]`, s8)), []byte(tgt), []byte(`{"problem_key":"sqrt_x"}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 100 {
		t.Fatalf("换题不带区间/n 应用库内默认: want 100, got %d", score)
	}
	// 若错误沿用 target 的 [0,π] n=2，真值会变成 (π/6)(4√(π/2)+√π) ≈ 3.55，S_8 得 0 分
	// 换题且显式给 n 时按给定值（n=4 的 S_4 运行时算）
	s4 := simpsonTrueS(t, "sqrt_x", 4)
	score, _, _, err = scoreByExperiment("simpson_integration",
		[]byte(fmt.Sprintf(`[{"value":%.12g}]`, s4)), []byte(tgt), []byte(`{"problem_key":"sqrt_x","n":4}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 100 {
		t.Fatalf("换题+显式 n: want 100, got %d", score)
	}
}

// ========== L18 逐次线性插值法（Aitken/Neville） ==========

const aitkenTarget = `{"method":"aitken_rel_err","problem_key":"sin_quad","pass_score":60}`

func submitAitken(t *testing.T, readings, userConfig string) (int, bool, string) {
	t.Helper()
	uc := []byte(nil)
	if userConfig != "" {
		uc = []byte(userConfig)
	}
	score, passed, detail, err := scoreByExperiment("aitken_interp", []byte(readings), []byte(aitkenTarget), uc)
	if err != nil {
		t.Fatalf("readings=%s user_config=%s: %v", readings, userConfig, err)
	}
	return score, passed, detail
}

// nevilleTrueP 运行时算库内题递推真值（测试与评分共用同一 nevilleEval，
// 另以 lagrangeEval 交叉验证——两路计算同一插值多项式必相等）。
func nevilleTrueP(t *testing.T, key string, xEval float64) float64 {
	t.Helper()
	def := interpProblems[key]
	if xEval != xEval { // NaN -> 用库内默认求值点
		xEval = def.XEval
	}
	p, err := nevilleEval(def.Xs, def.Ys, xEval)
	if err != nil {
		t.Fatalf("nevilleEval(%s, %g): %v", key, xEval, err)
	}
	return p
}

func TestScoreAitkenInterp_NevilleEqualsLagrange(t *testing.T) {
	// 核心交叉验证：Neville 递推与拉格朗日公式评同一插值多项式，
	// 题库全部三题（含自定义 4 节点）两路结果须一致到 1e-12
	for _, key := range []string{"sin_quad", "sqrt_table", "runge_5"} {
		def := interpProblems[key]
		nv, err := nevilleEval(def.Xs, def.Ys, def.XEval)
		if err != nil {
			t.Fatalf("nevilleEval(%s): %v", key, err)
		}
		lg, err := lagrangeEval(def.Xs, def.Ys, def.XEval)
		if err != nil {
			t.Fatalf("lagrangeEval(%s): %v", key, err)
		}
		if math.Abs(nv-lg) > 1e-12 {
			t.Errorf("%s: neville %.15g != lagrange %.15g", key, nv, lg)
		}
	}
	// 自定义 4 节点（含乱序符号的 y）
	xs := []float64{-2, 0, 1, 3}
	ys := []float64{5, -1, 2, 0.5}
	for _, xe := range []float64{-1, 0.7, 2.2} {
		nv, _ := nevilleEval(xs, ys, xe)
		lg, _ := lagrangeEval(xs, ys, xe)
		if math.Abs(nv-lg) > 1e-12 {
			t.Errorf("custom x_eval=%g: neville %.15g != lagrange %.15g", xe, nv, lg)
		}
	}
}

func TestScoreAitkenInterp_ExactSolution(t *testing.T) {
	// sin_quad P(π/6) = (4√2−1)/9（与 L16 同一真值，闭式解交叉验证）；
	// 第 1 列闭式：P_{1,1}=√2/3（(0,0)-(π/4,√2/2) 线性插值在 π/6），
	// P_{2,1}=(2√2−1)/3（(π/4,√2/2)-(π/2,1) 线性插值在 π/6）
	wantP := (4*math.Sqrt2 - 1) / 9
	got := nevilleTrueP(t, "sin_quad", math.Pi/6)
	if math.Abs(got-wantP) > 1e-12 {
		t.Fatalf("sin_quad 递推真值: want %.12g, got %.12g", wantP, got)
	}
	p11 := math.Sqrt2 / 3
	p21 := (2*math.Sqrt2 - 1) / 3
	readings := fmt.Sprintf(`[{"value":%.12g,"col1":[%.12g,%.12g]}]`, got, p11, p21)
	score, passed, detail := submitAitken(t, readings, "")
	if score != 100 || !passed {
		t.Fatalf("want 100/passed, got %d/%v (detail=%s)", score, passed, detail)
	}
	if !strings.Contains(detail, "problem=sin_quad") || !strings.Contains(detail, "n=3") {
		t.Errorf("detail 应记录 problem/n: %s", detail)
	}
	if !strings.Contains(detail, "col1=[0.471405,0.609476]") {
		t.Errorf("detail 应记录 col1: %s", detail)
	}
}

func TestScoreAitkenInterp_RelErrCurve(t *testing.T) {
	p := nevilleTrueP(t, "sin_quad", math.NaN())
	for _, c := range []struct {
		relErr float64
		want   int
	}{
		{1e-7, 100},
		{1e-4, 90},
		{1e-3, 80},
		{1e-2, 65},
		{0.1, 30},
		{0.5, 0},
	} {
		readings := fmt.Sprintf(`[{"value":%.12g}]`, p*(1+c.relErr))
		if score, _, _ := submitAitken(t, readings, ""); score != c.want {
			t.Errorf("rel_err=%g: want %d, got %d", c.relErr, c.want, score)
		}
	}
}

func TestScoreAitkenInterp_RungeAntiCheat(t *testing.T) {
	// 龙格现象题：递推终值 P(0.8) ≈ −0.379310 而 f(0.8) = 1/17 ≈ 0.058824。
	// 不做递推直接抄原函数值 -> 相对误差 ~1.15 -> 0 分（同 L16 天然防抄 f 值）
	p := nevilleTrueP(t, "runge_5", math.NaN())
	if p >= 0 {
		t.Fatalf("runge_5 P(0.8) 应为负（龙格振荡），got %g", p)
	}
	if score, _, _ := submitAitken(t, fmt.Sprintf(`[{"value":%.12g}]`, p), `{"problem_key":"runge_5"}`); score != 100 {
		t.Fatalf("递推真值: want 100, got %d", score)
	}
	if score, passed, _ := submitAitken(t, fmt.Sprintf(`[{"value":%.12g}]`, 1.0/17), `{"problem_key":"runge_5"}`); score != 0 || passed {
		t.Fatalf("抄 f 值: want 0/not passed, got %d/%v", score, passed)
	}
}

func TestScoreAitkenInterp_UserConfigProblemKey(t *testing.T) {
	// 换题 sqrt_table：P(115) ≈ 10.722756（与 L16 真值一致）
	p := nevilleTrueP(t, "sqrt_table", math.NaN())
	if math.Abs(p-10.722756) > 1e-6 {
		t.Fatalf("sqrt_table P(115): want ~10.722756, got %g", p)
	}
	score, _, detail := submitAitken(t, fmt.Sprintf(`[{"value":%.12g}]`, p), `{"problem_key":"sqrt_table"}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "problem=sqrt_table") {
		t.Errorf("detail 应记录换题后的 problem: %s", detail)
	}
}

func TestScoreAitkenInterp_UserConfigCustomNodes(t *testing.T) {
	// 自定义 3 节点 (0,0),(1,1),(2,4) 递推 x²，P(0.5) = 0.25
	score, _, detail := submitAitken(t, `[{"value":0.25}]`, `{"nodes_x":[0,1,2],"nodes_y":[0,1,4],"x_eval":0.5}`)
	if score != 100 {
		t.Fatalf("want 100, got %d (detail=%s)", score, detail)
	}
	if !strings.Contains(detail, "problem=custom") {
		t.Errorf("detail 应记录 problem=custom: %s", detail)
	}
}

func TestScoreAitkenInterp_UserConfigXEval(t *testing.T) {
	// 覆盖求值点：节点处 P(π/4) = √2/2（插值多项式过节点）
	if score, _, _ := submitAitken(t, fmt.Sprintf(`[{"value":%.12g}]`, math.Sqrt2/2), `{"x_eval":0.7853981633974483}`); score != 100 {
		t.Fatalf("节点处求值: want 100, got %d", score)
	}
	// 非节点处 x_eval=π/3，真值运行时算
	p := nevilleTrueP(t, "sin_quad", math.Pi/3)
	if score, _, _ := submitAitken(t, fmt.Sprintf(`[{"value":%.12g}]`, p), `{"x_eval":1.0471975511965976}`); score != 100 {
		t.Fatalf("x_eval 覆盖: want 100, got %d", score)
	}
}

func TestScoreAitkenInterp_Col1Audit(t *testing.T) {
	// col1 可选：值随意不参与打分，只须长度=n−1 且有限，记入审计 detail
	score, _, detail := submitAitken(t, `[{"value":0.5174282,"col1":[9,-4]}]`, "")
	if score != 100 {
		t.Fatalf("col1 不影响打分: want 100, got %d", score)
	}
	if !strings.Contains(detail, "col1=[9,-4]") {
		t.Errorf("detail 应原样记录 col1: %s", detail)
	}
}

func TestScoreAitkenInterp_BadInput(t *testing.T) {
	cases := []struct {
		name, readings, userConfig string
	}{
		{"缺 value", `[{"col1":[1,2]}]`, ""},
		{"value 为 NaN", `[{"value":NaN}]`, ""},
		{"非法 JSON", `[{"value":abc}]`, ""},
		{"col1 长度错", `[{"value":0.5,"col1":[1,2,3]}]`, ""},
		{"col1 含 NaN", `[{"value":0.5,"col1":[1,NaN]}]`, ""},
		{"未知插值题", `[{"value":0.5}]`, `{"problem_key":"nope"}`},
		{"自定义缺 x_eval", `[{"value":0.5}]`, `{"nodes_x":[0,1,2],"nodes_y":[0,1,4]}`},
		{"自定义 x 重复", `[{"value":0.5}]`, `{"nodes_x":[1,1,2],"nodes_y":[0,1,4],"x_eval":1.5}`},
		{"自定义 x/y 不匹配", `[{"value":0.5}]`, `{"nodes_x":[0,1,2],"nodes_y":[0,1],"x_eval":1.5}`},
		{"自定义节点数 9", `[{"value":0.5}]`, `{"nodes_x":[1,2,3,4,5,6,7,8,9],"nodes_y":[1,2,3,4,5,6,7,8,9],"x_eval":5}`},
	}
	for _, c := range cases {
		uc := []byte(nil)
		if c.userConfig != "" {
			uc = []byte(c.userConfig)
		}
		if _, _, _, err := scoreByExperiment("aitken_interp", []byte(c.readings), []byte(aitkenTarget), uc); err == nil {
			t.Errorf("%s: want error, got nil", c.name)
		}
	}
}

func TestScoreAitkenInterp_TargetXEvalOnlyForTargetProblem(t *testing.T) {
	// target 带 sin_quad 的求值点（真库 target 即如此）；user_config 换 runge_5
	// 不带 x_eval 时，应用 runge_5 库内默认 0.8，而非沿用 target 的
	//（target 的题专属参数只属于 target 自己的题，v0.12.1 规则同款）
	tgt := `{"method":"aitken_rel_err","problem_key":"sin_quad","x_eval":0.5235987755982988,"pass_score":60}`
	p := nevilleTrueP(t, "runge_5", math.NaN()) // 库内默认 0.8
	score, _, _, err := scoreByExperiment("aitken_interp",
		[]byte(fmt.Sprintf(`[{"value":%.12g}]`, p)), []byte(tgt), []byte(`{"problem_key":"runge_5"}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 100 {
		t.Fatalf("换题不带 x_eval 应用库内默认求值点: want 100, got %d", score)
	}
	// 换题且显式给 x_eval 时按给定值（0.5 是 runge_5 节点，P=f(0.5)=4/29）
	score, _, _, err = scoreByExperiment("aitken_interp",
		[]byte(fmt.Sprintf(`[{"value":%.12g}]`, 4.0/29)), []byte(tgt), []byte(`{"problem_key":"runge_5","x_eval":0.5}`))
	if err != nil {
		t.Fatal(err)
	}
	if score != 100 {
		t.Fatalf("换题+显式 x_eval: want 100, got %d", score)
	}
}
