// pages/experiments/oscilloscope/oscilloscope.js
import { request } from '../../../utils/request';

Page({
  data: {
    levelId: null,
    mode: 'CH1',
    modes: ['CH1', 'CH2', '李萨如'],
    ch1: { A: 2.0, f: 50, phi: 0 },
    ch2: { A: 1.5, f: 50, phi: Math.PI / 4 },
    readings: {
      ch1_f: '50',
      ch1_A: '2.0',
      ch2_f: '50',
      ch2_A: '1.5'
    },
    submitting: false,
    canvasWidth: 0,
    canvasHeight: 0,
    pixelRatio: 1
  },

  // 缓存的 canvas 节点
  _canvas: null,
  _ctx: null,
  _rafId: 0,

  onLoad(options) {
    this.setData({ levelId: options.levelId });
    this.initCanvas();
    if (options.levelId) {
      this.loadExperimentConfig(options.levelId);
    }
  },

  // 加载实验配置（GET /experiments/:id，:id 是 level_id）
  // 后端 config: { channels: { CH1:{A,f,phi}, CH2:{A,f,phi} } }
  async loadExperimentConfig(levelId) {
    try {
      const res = await request({
        url: `/experiments/${levelId}`,
        method: 'GET'
      });
      const data = res.data || res || {};
      const channels = data.config && data.config.channels;
      if (!channels) return;

      const ch1 = {
        A: channels.CH1 ? channels.CH1.A : this.data.ch1.A,
        f: channels.CH1 ? channels.CH1.f : this.data.ch1.f,
        phi: channels.CH1 && channels.CH1.phi != null ? channels.CH1.phi : this.data.ch1.phi
      };
      const ch2 = {
        A: channels.CH2 ? channels.CH2.A : this.data.ch2.A,
        f: channels.CH2 ? channels.CH2.f : this.data.ch2.f,
        phi: channels.CH2 && channels.CH2.phi != null ? channels.CH2.phi : this.data.ch2.phi
      };
      this.setData({
        ch1,
        ch2,
        readings: {
          ch1_f: String(ch1.f),
          ch1_A: String(ch1.A),
          ch2_f: String(ch2.f),
          ch2_A: String(ch2.A)
        }
      });
    } catch (err) {
      console.warn('[oscilloscope] 后端不可用，使用默认配置');
    }
  },

  onReady() {
    // 缓存 canvas 节点
    const query = wx.createSelectorQuery().in(this);
    query.select('#scopeCanvas')
      .fields({ node: true, size: true })
      .exec((res) => {
        if (!res[0]) {
          console.error('[oscilloscope] canvas 节点获取失败');
          return;
        }
        const canvas = res[0].node;
        this._canvas = canvas;
        this._ctx = canvas.getContext('2d');
        this.startAnimation();
      });
  },

  onUnload() {
    if (this._rafId) {
      this._canvas && this._canvas.cancelAnimationFrame(this._rafId);
    }
    this._canvas = null;
    this._ctx = null;
  },

  initCanvas() {
    const sysInfo = wx.getSystemInfoSync();
    const width = sysInfo.windowWidth;
    const height = Math.min(width * 0.6, 420);
    this.setData({
      canvasWidth: width,
      canvasHeight: height,
      pixelRatio: sysInfo.pixelRatio || 1
    });
  },

  // 开始动画循环（使用 canvas.requestAnimationFrame）
  startAnimation() {
    const canvas = this._canvas;
    if (!canvas) return;

    const loop = () => {
      this.drawScope();
      this._rafId = canvas.requestAnimationFrame(loop);
    };
    loop();
  },

  // 绘制示波器屏幕
  drawScope() {
    const canvas = this._canvas;
    const ctx = this._ctx;
    if (!canvas || !ctx) return;

    const { canvasWidth, canvasHeight, pixelRatio, mode } = this.data;
    const t = Date.now() / 1000;

    canvas.width = canvasWidth * pixelRatio;
    canvas.height = canvasHeight * pixelRatio;
    // 用 setTransform 重置变换，避免 scale 累积
    ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);

    const w = canvasWidth;
    const h = canvasHeight;

    // 示波器屏幕背景
    ctx.fillStyle = '#0a1a0a';
    ctx.fillRect(0, 0, w, h);

    // 网格
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.15)';
    ctx.lineWidth = 1;
    const gridSize = 40;
    for (let x = 0; x <= w; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y <= h; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // 坐标轴
    ctx.strokeStyle = 'rgba(0, 255, 0, 0.3)';
    ctx.beginPath();
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();

    if (mode === '李萨如') {
      this.drawLissajous(ctx, w, h, t);
    } else {
      this.drawWaveform(ctx, w, h, t);
    }
  },

  // 绘制时域波形
  drawWaveform(ctx, w, h, t) {
    const { ch1, ch2, mode } = this.data;
    const signal = mode === 'CH1' ? ch1 : ch2;
    const amplitudeScale = h / 8;
    const timeScale = w / 0.04;

    ctx.strokeStyle = '#00ff00';
    ctx.lineWidth = 2;
    ctx.beginPath();

    for (let px = 0; px <= w; px += 2) {
      const time = px / timeScale + t;
      const value = signal.A * Math.sin(2 * Math.PI * signal.f * time + signal.phi);
      const py = h / 2 - value * amplitudeScale;
      if (px === 0) {
        ctx.moveTo(px, py);
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.stroke();
  },

  // 绘制李萨如图形
  drawLissajous(ctx, w, h, t) {
    const { ch1, ch2 } = this.data;
    const scale = Math.min(w, h) / 6;
    const duration = 2 / Math.min(ch1.f, ch2.f || 1);
    const step = duration / 400;

    ctx.strokeStyle = '#00ff00';
    ctx.lineWidth = 2;
    ctx.beginPath();

    let first = true;
    for (let time = 0; time <= duration; time += step) {
      const x = ch1.A * Math.sin(2 * Math.PI * ch1.f * time + ch1.phi + t);
      const y = ch2.A * Math.sin(2 * Math.PI * ch2.f * time + ch2.phi + t);
      const px = w / 2 + x * scale;
      const py = h / 2 - y * scale;
      if (first) {
        ctx.moveTo(px, py);
        first = false;
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.stroke();
  },

  // 参数输入
  onParamInput(e) {
    const { ch, field } = e.currentTarget.dataset;
    const value = parseFloat(e.detail.value);
    if (isNaN(value)) return;

    this.setData({
      [`${ch}.${field}`]: value
    });

    const readingField = `${ch}_${field}`;
    if (this.data.readings[readingField] !== undefined) {
      this.setData({
        [`readings.${readingField}`]: e.detail.value
      });
    }

    // 真机 rAF 循环可能在输入框获焦时暂停，手动重绘确保波形立即更新
    // 用 setTimeout(0) 确保 setData 已应用后再绘制
    setTimeout(() => this.redraw(), 0);
  },

  // 手动重绘（rAF 停顿时的兜底）
  redraw() {
    if (!this._ctx) return;
    // 强制重设 canvas 尺寸触发画布清空，避免残影
    const { canvasWidth, canvasHeight, pixelRatio } = this.data;
    this._canvas.width = canvasWidth * pixelRatio;
    this._canvas.height = canvasHeight * pixelRatio;
    this.drawScope();
  },

  // 切换显示模式
  onModeChange(e) {
    this.setData({ mode: e.currentTarget.dataset.mode });
  },

  onReadingInput(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({
      [`readings.${field}`]: e.detail.value
    });
  },

  // 提交读数
  async submitReadings() {
    const { levelId, readings } = this.data;
    this.setData({ submitting: true });

    try {
      const res = await request({
        url: '/progress/submit',
        method: 'POST',
        data: {
          level_id: parseInt(levelId, 10) || 2,
          experiment: 'oscilloscope',
          readings: [
            { channel: 'CH1', f: parseFloat(readings.ch1_f) || 0, A: parseFloat(readings.ch1_A) || 0 },
            { channel: 'CH2', f: parseFloat(readings.ch2_f) || 0, A: parseFloat(readings.ch2_A) || 0 }
          ]
        }
      });

      const data = res.data || res || {};
      wx.showModal({
        title: data.passed ? '恭喜过关' : '提交结果',
        content: `得分：${data.score}，最佳：${data.best_score}`,
        showCancel: false,
        success: () => {
          if (data.passed) wx.navigateBack();
        }
      });
    } catch (err) {
      console.error('[oscilloscope] 提交失败:', err);
      wx.showToast({ title: err.message || '提交失败', icon: 'none' });
    } finally {
      this.setData({ submitting: false });
    }
  }
});